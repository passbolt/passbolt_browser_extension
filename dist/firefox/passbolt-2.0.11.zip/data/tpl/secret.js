(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
window.templates = window.templates || {};
window.templates.secret = window.templates.secret || {};
window.templates.secret.criterias = require('./secret/criterias.js');
window.templates.secret.edit = require('./secret/edit.js');
window.templates.secret.securitytokenStyle = require('./secret/securitytokenStyle.js');
window.templates.secret.strength = require('./secret/strength.js');

},{"./secret/criterias.js":2,"./secret/edit.js":3,"./secret/securitytokenStyle.js":4,"./secret/strength.js":5}],2:[function(require,module,exports){
module.exports = function(locals, escapeFn, include, rethrow
) {
rethrow = rethrow || function rethrow(err, str, flnm, lineno, esc){
  var lines = str.split('\n');
  var start = Math.max(lineno - 3, 0);
  var end = Math.min(lines.length, lineno + 3);
  var filename = esc(flnm); // eslint-disable-line
  // Error context
  var context = lines.slice(start, end).map(function (line, i){
    var curr = i + start + 1;
    return (curr == lineno ? ' >> ' : '    ')
      + curr
      + '| '
      + line;
  }).join('\n');

  // Alter exception message
  err.path = filename;
  err.message = (filename || 'ejs') + ':'
    + lineno + '\n'
    + context + '\n\n'
    + err.message;

  throw err;
};
escapeFn = escapeFn || function (markup) {
  return markup == undefined
    ? ''
    : String(markup)
      .replace(_MATCH_HTML, encode_char);
};
var _ENCODE_HTML_RULES = {
      "&": "&amp;"
    , "<": "&lt;"
    , ">": "&gt;"
    , '"': "&#34;"
    , "'": "&#39;"
    }
  , _MATCH_HTML = /[&<>'"]/g;
function encode_char(c) {
  return _ENCODE_HTML_RULES[c] || c;
};
;
var __line = 1
  , __lines = "<?\nif (Object.keys(criterias).length == 0) {\n?>\n<li>It is at least 8 char in length </li>\n<li>It contains lower and uppercase character</li>\n<li>It contains letters and numbers</li>\n<li>It contains special characters (like / or * or %)</li>\n<li>It is not part of a dictionary</li>\n<? } else { ?>\n<li class=\"<?= criterias.minLength ? 'success' : 'error' ?>\">It is at least 8 char in length</li>\n<li class=\"<?= criterias.alpha && criterias.uppercase ? 'success' : 'error' ?>\">It contains lower and uppercase character</li>\n<li class=\"<?= (criterias.alpha || criterias.uppercase) && criterias.digit ? 'success' : 'error' ?>\">It contains letters and numbers</li>\n<li class=\"<?= criterias.special ? 'success' : 'error' ?>\">It contains special characters (like / or * or %)</li>\n<? if (typeof criterias.dictionary !== 'undefined') { ?>\n<li class=\"<?= criterias.dictionary ? 'success' : 'error' ?>\">It is not part of a dictionary</li>\n<? } else { ?>\n<li>It is not part of a dictionary (checking, please wait...)</li>\n<? } ?>\n<? } ?>\n"
  , __filename = "src/all/data/ejs/secret/criterias.ejs";
try {
  var __output = [], __append = __output.push.bind(__output);
  with (locals || {}) {
    ; 
if (Object.keys(criterias).length == 0) {

    ; __line = 3
    ; __append("\n<li>It is at least 8 char in length </li>\n<li>It contains lower and uppercase character</li>\n<li>It contains letters and numbers</li>\n<li>It contains special characters (like / or * or %)</li>\n<li>It is not part of a dictionary</li>\n")
    ; __line = 9
    ;  } else { 
    ; __append("\n<li class=\"")
    ; __line = 10
    ; __append(escapeFn( criterias.minLength ? 'success' : 'error' ))
    ; __append("\">It is at least 8 char in length</li>\n<li class=\"")
    ; __line = 11
    ; __append(escapeFn( criterias.alpha && criterias.uppercase ? 'success' : 'error' ))
    ; __append("\">It contains lower and uppercase character</li>\n<li class=\"")
    ; __line = 12
    ; __append(escapeFn( (criterias.alpha || criterias.uppercase) && criterias.digit ? 'success' : 'error' ))
    ; __append("\">It contains letters and numbers</li>\n<li class=\"")
    ; __line = 13
    ; __append(escapeFn( criterias.special ? 'success' : 'error' ))
    ; __append("\">It contains special characters (like / or * or %)</li>\n")
    ; __line = 14
    ;  if (typeof criterias.dictionary !== 'undefined') { 
    ; __append("\n<li class=\"")
    ; __line = 15
    ; __append(escapeFn( criterias.dictionary ? 'success' : 'error' ))
    ; __append("\">It is not part of a dictionary</li>\n")
    ; __line = 16
    ;  } else { 
    ; __append("\n<li>It is not part of a dictionary (checking, please wait...)</li>\n")
    ; __line = 18
    ;  } 
    ; __append("\n")
    ; __line = 19
    ;  } 
    ; __append("\n")
    ; __line = 20
  }
  return __output.join("");
} catch (e) {
  rethrow(e, __lines, __filename, __line, escapeFn);
}

}
},{}],3:[function(require,module,exports){
module.exports = function(locals, escapeFn, include, rethrow
) {
rethrow = rethrow || function rethrow(err, str, flnm, lineno, esc){
  var lines = str.split('\n');
  var start = Math.max(lineno - 3, 0);
  var end = Math.min(lines.length, lineno + 3);
  var filename = esc(flnm); // eslint-disable-line
  // Error context
  var context = lines.slice(start, end).map(function (line, i){
    var curr = i + start + 1;
    return (curr == lineno ? ' >> ' : '    ')
      + curr
      + '| '
      + line;
  }).join('\n');

  // Alter exception message
  err.path = filename;
  err.message = (filename || 'ejs') + ':'
    + lineno + '\n'
    + context + '\n\n'
    + err.message;

  throw err;
};
escapeFn = escapeFn || function (markup) {
  return markup == undefined
    ? ''
    : String(markup)
      .replace(_MATCH_HTML, encode_char);
};
var _ENCODE_HTML_RULES = {
      "&": "&amp;"
    , "<": "&lt;"
    , ">": "&gt;"
    , '"': "&#34;"
    , "'": "&#39;"
    }
  , _MATCH_HTML = /[&<>'"]/g;
function encode_char(c) {
  return _ENCODE_HTML_RULES[c] || c;
};
;
var __line = 1
  , __lines = "\n<div class=\"form-content\">\n    <div class=\"input-password-wrapper\">\n        <input type=\"hidden\" id=\"js_field_secret_id\" />\n        <div class=\"input password required\">\n            <input maxlength=\"4096\" type=\"password\" id=\"js_secret\" placeholder=\"password\" value=\"\"/>\n            <input maxlength=\"4096\" type=\"text\" id=\"js_secret_clear\" placeholder=\"password\" class=\"hidden\"/>\n            <div class=\"security-token\"></div>\n        </div>\n        <ul class=\"actions inline\">\n            <li>\n                <a id=\"js_secret_view\" class=\"button toggle\">\n                    <i class=\"fa fa-eye fa-fw fa-lg\"></i>\n                    <span class=\"visuallyhidden\">view</span>\n                </a>\n            </li>\n            <li>\n                <a id=\"js_secret_generate\" class=\"button\">\n                    <i class=\"fa fa-magic fa-fw fa-lg\"></i>\n                    <span class=\"visuallyhidden\">generate</span>\n                </a>\n            </li>\n        </ul>\n\n        <div id=\"js_secret_strength\" class=\"password-complexity\">\n        </div>\n\n        <div class=\"input text\">\n            <div id=\"js_field_password_feedback\" class=\"message error\">\n            </div>\n        </div>\n    </div>\n</div>\n"
  , __filename = "src/all/data/ejs/secret/edit.ejs";
try {
  var __output = [], __append = __output.push.bind(__output);
  with (locals || {}) {
    ; __append("\n<div class=\"form-content\">\n    <div class=\"input-password-wrapper\">\n        <input type=\"hidden\" id=\"js_field_secret_id\" />\n        <div class=\"input password required\">\n            <input maxlength=\"4096\" type=\"password\" id=\"js_secret\" placeholder=\"password\" value=\"\"/>\n            <input maxlength=\"4096\" type=\"text\" id=\"js_secret_clear\" placeholder=\"password\" class=\"hidden\"/>\n            <div class=\"security-token\"></div>\n        </div>\n        <ul class=\"actions inline\">\n            <li>\n                <a id=\"js_secret_view\" class=\"button toggle\">\n                    <i class=\"fa fa-eye fa-fw fa-lg\"></i>\n                    <span class=\"visuallyhidden\">view</span>\n                </a>\n            </li>\n            <li>\n                <a id=\"js_secret_generate\" class=\"button\">\n                    <i class=\"fa fa-magic fa-fw fa-lg\"></i>\n                    <span class=\"visuallyhidden\">generate</span>\n                </a>\n            </li>\n        </ul>\n\n        <div id=\"js_secret_strength\" class=\"password-complexity\">\n        </div>\n\n        <div class=\"input text\">\n            <div id=\"js_field_password_feedback\" class=\"message error\">\n            </div>\n        </div>\n    </div>\n</div>\n")
    ; __line = 34
  }
  return __output.join("");
} catch (e) {
  rethrow(e, __lines, __filename, __line, escapeFn);
}

}
},{}],4:[function(require,module,exports){
module.exports = function(locals, escapeFn, include, rethrow
) {
rethrow = rethrow || function rethrow(err, str, flnm, lineno, esc){
  var lines = str.split('\n');
  var start = Math.max(lineno - 3, 0);
  var end = Math.min(lines.length, lineno + 3);
  var filename = esc(flnm); // eslint-disable-line
  // Error context
  var context = lines.slice(start, end).map(function (line, i){
    var curr = i + start + 1;
    return (curr == lineno ? ' >> ' : '    ')
      + curr
      + '| '
      + line;
  }).join('\n');

  // Alter exception message
  err.path = filename;
  err.message = (filename || 'ejs') + ':'
    + lineno + '\n'
    + context + '\n\n'
    + err.message;

  throw err;
};
escapeFn = escapeFn || function (markup) {
  return markup == undefined
    ? ''
    : String(markup)
      .replace(_MATCH_HTML, encode_char);
};
var _ENCODE_HTML_RULES = {
      "&": "&amp;"
    , "<": "&lt;"
    , ">": "&gt;"
    , '"': "&#34;"
    , "'": "&#39;"
    }
  , _MATCH_HTML = /[&<>'"]/g;
function encode_char(c) {
  return _ENCODE_HTML_RULES[c] || c;
};
;
var __line = 1
  , __lines = "<style>\n    <?= id ?>:focus,\n    <?= id ?> ~ .security-token {\n        background: <?= color ?>;\n        color: <?= textcolor ?>;\n    }\n    <?= id ?>:focus ~ .security-token {\n        background: <?= textcolor ?>;\n        color: <?= color ?>;\n    };\n</style>"
  , __filename = "src/all/data/ejs/secret/securitytokenStyle.ejs";
try {
  var __output = [], __append = __output.push.bind(__output);
  with (locals || {}) {
    ; __append("<style>\n    ")
    ; __line = 2
    ; __append(escapeFn( id ))
    ; __append(":focus,\n    ")
    ; __line = 3
    ; __append(escapeFn( id ))
    ; __append(" ~ .security-token {\n        background: ")
    ; __line = 4
    ; __append(escapeFn( color ))
    ; __append(";\n        color: ")
    ; __line = 5
    ; __append(escapeFn( textcolor ))
    ; __append(";\n    }\n    ")
    ; __line = 7
    ; __append(escapeFn( id ))
    ; __append(":focus ~ .security-token {\n        background: ")
    ; __line = 8
    ; __append(escapeFn( textcolor ))
    ; __append(";\n        color: ")
    ; __line = 9
    ; __append(escapeFn( color ))
    ; __append(";\n    };\n</style>")
    ; __line = 11
  }
  return __output.join("");
} catch (e) {
  rethrow(e, __lines, __filename, __line, escapeFn);
}

}
},{}],5:[function(require,module,exports){
module.exports = function(locals, escapeFn, include, rethrow
) {
rethrow = rethrow || function rethrow(err, str, flnm, lineno, esc){
  var lines = str.split('\n');
  var start = Math.max(lineno - 3, 0);
  var end = Math.min(lines.length, lineno + 3);
  var filename = esc(flnm); // eslint-disable-line
  // Error context
  var context = lines.slice(start, end).map(function (line, i){
    var curr = i + start + 1;
    return (curr == lineno ? ' >> ' : '    ')
      + curr
      + '| '
      + line;
  }).join('\n');

  // Alter exception message
  err.path = filename;
  err.message = (filename || 'ejs') + ':'
    + lineno + '\n'
    + context + '\n\n'
    + err.message;

  throw err;
};
escapeFn = escapeFn || function (markup) {
  return markup == undefined
    ? ''
    : String(markup)
      .replace(_MATCH_HTML, encode_char);
};
var _ENCODE_HTML_RULES = {
      "&": "&amp;"
    , "<": "&lt;"
    , ">": "&gt;"
    , '"': "&#34;"
    , "'": "&#39;"
    }
  , _MATCH_HTML = /[&<>'"]/g;
function encode_char(c) {
  return _ENCODE_HTML_RULES[c] || c;
};
;
var __line = 1
  , __lines = "<span class=\"progress\"><span class=\"progress-bar <?= strengthId ?>\"></span></span>\n<span class=\"complexity-text\">complexity: <strong><?= strengthLabel ?></strong></span>\n"
  , __filename = "src/all/data/ejs/secret/strength.ejs";
try {
  var __output = [], __append = __output.push.bind(__output);
  with (locals || {}) {
    ; __append("<span class=\"progress\"><span class=\"progress-bar ")
    ; __append(escapeFn( strengthId ))
    ; __append("\"></span></span>\n<span class=\"complexity-text\">complexity: <strong>")
    ; __line = 2
    ; __append(escapeFn( strengthLabel ))
    ; __append("</strong></span>\n")
    ; __line = 3
  }
  return __output.join("");
} catch (e) {
  rethrow(e, __lines, __filename, __line, escapeFn);
}

}
},{}]},{},[1]);
