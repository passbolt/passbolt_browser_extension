(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
window.templates = window.templates || {};
window.templates.secret = window.templates.secret || {};
window.templates.secret.criterias = require('./secret/criterias.js');
window.templates.secret.securitytokenStyle = require('./secret/securitytokenStyle.js');
window.templates.secret.strength = require('./secret/strength.js');

},{"./secret/criterias.js":2,"./secret/securitytokenStyle.js":3,"./secret/strength.js":4}],2:[function(require,module,exports){
module.exports = function(locals, escapeFn, include, rethrow
) {
rethrow = rethrow || function rethrow(err, str, flnm, lineno, esc){
  var lines = str.split('\n');
  var start = Math.max(lineno - 3, 0);
  var end = Math.min(lines.length, lineno + 3);
  var filename = esc(flnm); // eslint-disable-line
  // Error context
  var context = lines.slice(start, end).map(function (line, i){
    var curr = i + start + 1;
    return (curr == lineno ? ' >> ' : '    ')
      + curr
      + '| '
      + line;
  }).join('\n');

  // Alter exception message
  err.path = filename;
  err.message = (filename || 'ejs') + ':'
    + lineno + '\n'
    + context + '\n\n'
    + err.message;

  throw err;
};
escapeFn = escapeFn || function (markup) {
  return markup == undefined
    ? ''
    : String(markup)
      .replace(_MATCH_HTML, encode_char);
};
var _ENCODE_HTML_RULES = {
      "&": "&amp;"
    , "<": "&lt;"
    , ">": "&gt;"
    , '"': "&#34;"
    , "'": "&#39;"
    }
  , _MATCH_HTML = /[&<>'"]/g;
function encode_char(c) {
  return _ENCODE_HTML_RULES[c] || c;
};
;
var __line = 1
  , __lines = "<?\nif (Object.keys(criterias).length == 0) {\n?>\n<li>It is at least 8 char in length </li>\n<li>It contains lower and uppercase character</li>\n<li>It contains letters and numbers</li>\n<li>It contains special characters (like / or * or %)</li>\n<li>It is not part of a dictionary</li>\n<? } else { ?>\n<li class=\"<?= criterias.minLength ? 'success' : 'error' ?>\">It is at least 8 char in length</li>\n<li class=\"<?= criterias.alpha && criterias.uppercase ? 'success' : 'error' ?>\">It contains lower and uppercase character</li>\n<li class=\"<?= (criterias.alpha || criterias.uppercase) && criterias.digit ? 'success' : 'error' ?>\">It contains letters and numbers</li>\n<li class=\"<?= criterias.special ? 'success' : 'error' ?>\">It contains special characters (like / or * or %)</li>\n<? if (typeof criterias.dictionary !== 'undefined') { ?>\n<li class=\"<?= criterias.dictionary ? 'success' : 'error' ?>\">It is not part of a dictionary\n    <? if (typeof criterias.dictionary_error !== 'undefined') { ?>(network error)<? } ?>\n</li>\n<? } else { ?>\n<li>It is not part of a dictionary (checking, please wait...)</li>\n<? } ?>\n<? } ?>\n"
  , __filename = "src/all/data/ejs/secret/criterias.ejs";
try {
  var __output = "";
  function __append(s) { if (s !== undefined && s !== null) __output += s }
  with (locals || {}) {
    ; 
if (Object.keys(criterias).length == 0) {

    ; __line = 3
    ; __append("\n<li>It is at least 8 char in length </li>\n<li>It contains lower and uppercase character</li>\n<li>It contains letters and numbers</li>\n<li>It contains special characters (like / or * or %)</li>\n<li>It is not part of a dictionary</li>\n")
    ; __line = 9
    ;  } else { 
    ; __append("\n<li class=\"")
    ; __line = 10
    ; __append(escapeFn( criterias.minLength ? 'success' : 'error' ))
    ; __append("\">It is at least 8 char in length</li>\n<li class=\"")
    ; __line = 11
    ; __append(escapeFn( criterias.alpha && criterias.uppercase ? 'success' : 'error' ))
    ; __append("\">It contains lower and uppercase character</li>\n<li class=\"")
    ; __line = 12
    ; __append(escapeFn( (criterias.alpha || criterias.uppercase) && criterias.digit ? 'success' : 'error' ))
    ; __append("\">It contains letters and numbers</li>\n<li class=\"")
    ; __line = 13
    ; __append(escapeFn( criterias.special ? 'success' : 'error' ))
    ; __append("\">It contains special characters (like / or * or %)</li>\n")
    ; __line = 14
    ;  if (typeof criterias.dictionary !== 'undefined') { 
    ; __append("\n<li class=\"")
    ; __line = 15
    ; __append(escapeFn( criterias.dictionary ? 'success' : 'error' ))
    ; __append("\">It is not part of a dictionary\n    ")
    ; __line = 16
    ;  if (typeof criterias.dictionary_error !== 'undefined') { 
    ; __append("(network error)")
    ;  } 
    ; __append("\n</li>\n")
    ; __line = 18
    ;  } else { 
    ; __append("\n<li>It is not part of a dictionary (checking, please wait...)</li>\n")
    ; __line = 20
    ;  } 
    ; __append("\n")
    ; __line = 21
    ;  } 
    ; __append("\n")
    ; __line = 22
  }
  return __output;
} catch (e) {
  rethrow(e, __lines, __filename, __line, escapeFn);
}

//# sourceURL=src/all/data/ejs/secret/criterias.ejs

}
},{}],3:[function(require,module,exports){
module.exports = function(locals, escapeFn, include, rethrow
) {
rethrow = rethrow || function rethrow(err, str, flnm, lineno, esc){
  var lines = str.split('\n');
  var start = Math.max(lineno - 3, 0);
  var end = Math.min(lines.length, lineno + 3);
  var filename = esc(flnm); // eslint-disable-line
  // Error context
  var context = lines.slice(start, end).map(function (line, i){
    var curr = i + start + 1;
    return (curr == lineno ? ' >> ' : '    ')
      + curr
      + '| '
      + line;
  }).join('\n');

  // Alter exception message
  err.path = filename;
  err.message = (filename || 'ejs') + ':'
    + lineno + '\n'
    + context + '\n\n'
    + err.message;

  throw err;
};
escapeFn = escapeFn || function (markup) {
  return markup == undefined
    ? ''
    : String(markup)
      .replace(_MATCH_HTML, encode_char);
};
var _ENCODE_HTML_RULES = {
      "&": "&amp;"
    , "<": "&lt;"
    , ">": "&gt;"
    , '"': "&#34;"
    , "'": "&#39;"
    }
  , _MATCH_HTML = /[&<>'"]/g;
function encode_char(c) {
  return _ENCODE_HTML_RULES[c] || c;
};
;
var __line = 1
  , __lines = "<style>\n    <?= id ?>:focus,\n    <?= id ?> ~ .security-token {\n        background: <?= color ?>;\n        color: <?= textcolor ?>;\n    }\n    <?= id ?>:focus ~ .security-token {\n        background: <?= textcolor ?>;\n        color: <?= color ?>;\n    };\n</style>"
  , __filename = "src/all/data/ejs/secret/securitytokenStyle.ejs";
try {
  var __output = "";
  function __append(s) { if (s !== undefined && s !== null) __output += s }
  with (locals || {}) {
    ; __append("<style>\n    ")
    ; __line = 2
    ; __append(escapeFn( id ))
    ; __append(":focus,\n    ")
    ; __line = 3
    ; __append(escapeFn( id ))
    ; __append(" ~ .security-token {\n        background: ")
    ; __line = 4
    ; __append(escapeFn( color ))
    ; __append(";\n        color: ")
    ; __line = 5
    ; __append(escapeFn( textcolor ))
    ; __append(";\n    }\n    ")
    ; __line = 7
    ; __append(escapeFn( id ))
    ; __append(":focus ~ .security-token {\n        background: ")
    ; __line = 8
    ; __append(escapeFn( textcolor ))
    ; __append(";\n        color: ")
    ; __line = 9
    ; __append(escapeFn( color ))
    ; __append(";\n    };\n</style>")
    ; __line = 11
  }
  return __output;
} catch (e) {
  rethrow(e, __lines, __filename, __line, escapeFn);
}

//# sourceURL=src/all/data/ejs/secret/securitytokenStyle.ejs

}
},{}],4:[function(require,module,exports){
module.exports = function(locals, escapeFn, include, rethrow
) {
rethrow = rethrow || function rethrow(err, str, flnm, lineno, esc){
  var lines = str.split('\n');
  var start = Math.max(lineno - 3, 0);
  var end = Math.min(lines.length, lineno + 3);
  var filename = esc(flnm); // eslint-disable-line
  // Error context
  var context = lines.slice(start, end).map(function (line, i){
    var curr = i + start + 1;
    return (curr == lineno ? ' >> ' : '    ')
      + curr
      + '| '
      + line;
  }).join('\n');

  // Alter exception message
  err.path = filename;
  err.message = (filename || 'ejs') + ':'
    + lineno + '\n'
    + context + '\n\n'
    + err.message;

  throw err;
};
escapeFn = escapeFn || function (markup) {
  return markup == undefined
    ? ''
    : String(markup)
      .replace(_MATCH_HTML, encode_char);
};
var _ENCODE_HTML_RULES = {
      "&": "&amp;"
    , "<": "&lt;"
    , ">": "&gt;"
    , '"': "&#34;"
    , "'": "&#39;"
    }
  , _MATCH_HTML = /[&<>'"]/g;
function encode_char(c) {
  return _ENCODE_HTML_RULES[c] || c;
};
;
var __line = 1
  , __lines = "<span class=\"progress\"><span class=\"progress-bar <?= strengthId ?>\"></span></span>\n<span class=\"complexity-text\">complexity: <strong><?= strengthLabel ?></strong></span>\n"
  , __filename = "src/all/data/ejs/secret/strength.ejs";
try {
  var __output = "";
  function __append(s) { if (s !== undefined && s !== null) __output += s }
  with (locals || {}) {
    ; __append("<span class=\"progress\"><span class=\"progress-bar ")
    ; __append(escapeFn( strengthId ))
    ; __append("\"></span></span>\n<span class=\"complexity-text\">complexity: <strong>")
    ; __line = 2
    ; __append(escapeFn( strengthLabel ))
    ; __append("</strong></span>\n")
    ; __line = 3
  }
  return __output;
} catch (e) {
  rethrow(e, __lines, __filename, __line, escapeFn);
}

//# sourceURL=src/all/data/ejs/secret/strength.ejs

}
},{}]},{},[1]);
//result must be structured-clonable data
undefined;
