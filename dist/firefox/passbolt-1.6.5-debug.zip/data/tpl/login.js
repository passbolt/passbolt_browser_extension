(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
window.templates = window.templates || {};
window.templates.login = window.templates.login || {};
window.templates.login.feedbackLoginError = require('./login/feedbackLoginError.js');
window.templates.login.feedbackLoginNoUser = require('./login/feedbackLoginNoUser.js');
window.templates.login.feedbackLoginOops = require('./login/feedbackLoginOops.js');
window.templates.login.feedbackPassphraseOk = require('./login/feedbackPassphraseOk.js');
window.templates.login.form = require('./login/form.js');
window.templates.login.message = require('./login/message.js');
window.templates.login.noconfig = require('./login/noconfig.js');
window.templates.login.stage0 = require('./login/stage0.js');
window.templates.login.wrongDomain = require('./login/wrongDomain.js');

},{"./login/feedbackLoginError.js":2,"./login/feedbackLoginNoUser.js":3,"./login/feedbackLoginOops.js":4,"./login/feedbackPassphraseOk.js":5,"./login/form.js":6,"./login/message.js":7,"./login/noconfig.js":8,"./login/stage0.js":9,"./login/wrongDomain.js":10}],2:[function(require,module,exports){
module.exports = function(locals, escapeFn, include, rethrow
/**/) {
rethrow = rethrow || function rethrow(err, str, flnm, lineno, esc){
  var lines = str.split('\n');
  var start = Math.max(lineno - 3, 0);
  var end = Math.min(lines.length, lineno + 3);
  var filename = esc(flnm); // eslint-disable-line
  // Error context
  var context = lines.slice(start, end).map(function (line, i){
    var curr = i + start + 1;
    return (curr == lineno ? ' >> ' : '    ')
      + curr
      + '| '
      + line;
  }).join('\n');

  // Alter exception message
  err.path = filename;
  err.message = (filename || 'ejs') + ':'
    + lineno + '\n'
    + context + '\n\n'
    + err.message;

  throw err;
};
escapeFn = escapeFn || function (markup) {
  return markup == undefined
    ? ''
    : String(markup)
        .replace(_MATCH_HTML, encode_char);
};
var _ENCODE_HTML_RULES = {
      "&": "&amp;"
    , "<": "&lt;"
    , ">": "&gt;"
    , '"': "&#34;"
    , "'": "&#39;"
    }
  , _MATCH_HTML = /[&<>'"]/g;
function encode_char(c) {
  return _ENCODE_HTML_RULES[c] || c;
};
;
var __line = 1
  , __lines = "<div class=\"feedback\">\n    <i class=\"fa fa-cog fa-warning huge\"></i>\n    <p><?= message ?></p>\n</div>"
  , __filename = "src/all/data/ejs/login/feedbackLoginError.ejs";
try {
  var __output = [], __append = __output.push.bind(__output);
  with (locals || {}) {
    ; __append("<div class=\"feedback\">\n    <i class=\"fa fa-cog fa-warning huge\"></i>\n    <p>")
    ; __line = 3
    ; __append(escapeFn( message ))
    ; __append("</p>\n</div>")
    ; __line = 4
  }
  return __output.join("");
} catch (e) {
  rethrow(e, __lines, __filename, __line, escapeFn);
}

}
},{}],3:[function(require,module,exports){
module.exports = function(locals, escapeFn, include, rethrow
/**/) {
rethrow = rethrow || function rethrow(err, str, flnm, lineno, esc){
  var lines = str.split('\n');
  var start = Math.max(lineno - 3, 0);
  var end = Math.min(lines.length, lineno + 3);
  var filename = esc(flnm); // eslint-disable-line
  // Error context
  var context = lines.slice(start, end).map(function (line, i){
    var curr = i + start + 1;
    return (curr == lineno ? ' >> ' : '    ')
      + curr
      + '| '
      + line;
  }).join('\n');

  // Alter exception message
  err.path = filename;
  err.message = (filename || 'ejs') + ':'
    + lineno + '\n'
    + context + '\n\n'
    + err.message;

  throw err;
};
escapeFn = escapeFn || function (markup) {
  return markup == undefined
    ? ''
    : String(markup)
        .replace(_MATCH_HTML, encode_char);
};
var _ENCODE_HTML_RULES = {
      "&": "&amp;"
    , "<": "&lt;"
    , ">": "&gt;"
    , '"': "&#34;"
    , "'": "&#39;"
    }
  , _MATCH_HTML = /[&<>'"]/g;
function encode_char(c) {
  return _ENCODE_HTML_RULES[c] || c;
};
;
var __line = 1
  , __lines = "<div class=\"feedback\">\n    <i class=\"fa fa-meh-o huge\" ></i>\n    <p>The supplied account does not exist</p>\n</div>\n<div class=\"actions-wrapper center\">\n    <a class=\"button primary big\" href=\"register\">register again</a><br><br>\n    <a href=\"/recover\">or recover an existing account</a>\n</div>\n"
  , __filename = "src/all/data/ejs/login/feedbackLoginNoUser.ejs";
try {
  var __output = [], __append = __output.push.bind(__output);
  with (locals || {}) {
    ; __append("<div class=\"feedback\">\n    <i class=\"fa fa-meh-o huge\" ></i>\n    <p>The supplied account does not exist</p>\n</div>\n<div class=\"actions-wrapper center\">\n    <a class=\"button primary big\" href=\"register\">register again</a><br><br>\n    <a href=\"/recover\">or recover an existing account</a>\n</div>\n")
    ; __line = 9
  }
  return __output.join("");
} catch (e) {
  rethrow(e, __lines, __filename, __line, escapeFn);
}

}
},{}],4:[function(require,module,exports){
module.exports = function(locals, escapeFn, include, rethrow
/**/) {
rethrow = rethrow || function rethrow(err, str, flnm, lineno, esc){
  var lines = str.split('\n');
  var start = Math.max(lineno - 3, 0);
  var end = Math.min(lines.length, lineno + 3);
  var filename = esc(flnm); // eslint-disable-line
  // Error context
  var context = lines.slice(start, end).map(function (line, i){
    var curr = i + start + 1;
    return (curr == lineno ? ' >> ' : '    ')
      + curr
      + '| '
      + line;
  }).join('\n');

  // Alter exception message
  err.path = filename;
  err.message = (filename || 'ejs') + ':'
    + lineno + '\n'
    + context + '\n\n'
    + err.message;

  throw err;
};
escapeFn = escapeFn || function (markup) {
  return markup == undefined
    ? ''
    : String(markup)
        .replace(_MATCH_HTML, encode_char);
};
var _ENCODE_HTML_RULES = {
      "&": "&amp;"
    , "<": "&lt;"
    , ">": "&gt;"
    , '"': "&#34;"
    , "'": "&#39;"
    }
  , _MATCH_HTML = /[&<>'"]/g;
function encode_char(c) {
  return _ENCODE_HTML_RULES[c] || c;
};
;
var __line = 1
  , __lines = "<div class=\"feedback\">\n    <i class=\"fa fa-cog fa-warning huge\"></i>\n    <p>Oops, something went wrong</p>\n</div>\n<div class=\"actions-wrapper center\">\n    <a class=\"button primary big\" href=\"/auth/login\">Retry</a>\n</div>\n"
  , __filename = "src/all/data/ejs/login/feedbackLoginOops.ejs";
try {
  var __output = [], __append = __output.push.bind(__output);
  with (locals || {}) {
    ; __append("<div class=\"feedback\">\n    <i class=\"fa fa-cog fa-warning huge\"></i>\n    <p>Oops, something went wrong</p>\n</div>\n<div class=\"actions-wrapper center\">\n    <a class=\"button primary big\" href=\"/auth/login\">Retry</a>\n</div>\n")
    ; __line = 8
  }
  return __output.join("");
} catch (e) {
  rethrow(e, __lines, __filename, __line, escapeFn);
}

}
},{}],5:[function(require,module,exports){
module.exports = function(locals, escapeFn, include, rethrow
/**/) {
rethrow = rethrow || function rethrow(err, str, flnm, lineno, esc){
  var lines = str.split('\n');
  var start = Math.max(lineno - 3, 0);
  var end = Math.min(lines.length, lineno + 3);
  var filename = esc(flnm); // eslint-disable-line
  // Error context
  var context = lines.slice(start, end).map(function (line, i){
    var curr = i + start + 1;
    return (curr == lineno ? ' >> ' : '    ')
      + curr
      + '| '
      + line;
  }).join('\n');

  // Alter exception message
  err.path = filename;
  err.message = (filename || 'ejs') + ':'
    + lineno + '\n'
    + context + '\n\n'
    + err.message;

  throw err;
};
escapeFn = escapeFn || function (markup) {
  return markup == undefined
    ? ''
    : String(markup)
        .replace(_MATCH_HTML, encode_char);
};
var _ENCODE_HTML_RULES = {
      "&": "&amp;"
    , "<": "&lt;"
    , ">": "&gt;"
    , '"': "&#34;"
    , "'": "&#39;"
    }
  , _MATCH_HTML = /[&<>'"]/g;
function encode_char(c) {
  return _ENCODE_HTML_RULES[c] || c;
};
;
var __line = 1
  , __lines = "<div class=\"feedback\">\n    <i class=\"fa fa-cog fa-spin huge\"></i>\n    <p><?= message ?><br> please wait...</p>\n</div>"
  , __filename = "src/all/data/ejs/login/feedbackPassphraseOk.ejs";
try {
  var __output = [], __append = __output.push.bind(__output);
  with (locals || {}) {
    ; __append("<div class=\"feedback\">\n    <i class=\"fa fa-cog fa-spin huge\"></i>\n    <p>")
    ; __line = 3
    ; __append(escapeFn( message ))
    ; __append("<br> please wait...</p>\n</div>")
    ; __line = 4
  }
  return __output.join("");
} catch (e) {
  rethrow(e, __lines, __filename, __line, escapeFn);
}

}
},{}],6:[function(require,module,exports){
module.exports = function(locals, escapeFn, include, rethrow
/**/) {
rethrow = rethrow || function rethrow(err, str, flnm, lineno, esc){
  var lines = str.split('\n');
  var start = Math.max(lineno - 3, 0);
  var end = Math.min(lines.length, lineno + 3);
  var filename = esc(flnm); // eslint-disable-line
  // Error context
  var context = lines.slice(start, end).map(function (line, i){
    var curr = i + start + 1;
    return (curr == lineno ? ' >> ' : '    ')
      + curr
      + '| '
      + line;
  }).join('\n');

  // Alter exception message
  err.path = filename;
  err.message = (filename || 'ejs') + ':'
    + lineno + '\n'
    + context + '\n\n'
    + err.message;

  throw err;
};
escapeFn = escapeFn || function (markup) {
  return markup == undefined
    ? ''
    : String(markup)
        .replace(_MATCH_HTML, encode_char);
};
var _ENCODE_HTML_RULES = {
      "&": "&amp;"
    , "<": "&lt;"
    , ">": "&gt;"
    , '"': "&#34;"
    , "'": "&#39;"
    }
  , _MATCH_HTML = /[&<>'"]/g;
function encode_char(c) {
  return _ENCODE_HTML_RULES[c] || c;
};
;
var __line = 1
  , __lines = "<div class=\"page login-form master-password \">\n    <div class=\"input text required\">\n        <label for=\"UserUsername\">Username</label>\n        <input name=\"data[User][username]\" class=\"required fluid\" maxlength=\"50\" type=\"text\" id=\"UserUsername\"\n               required=\"required\"\n               value=\"\" disabled=\"disabled\"/>\n    </div>\n    <div class=\"input text required\">\n        <label for=\"js_master_password\">Master password</label>\n        <input type=\"password\" placeholder=\"password\" id=\"js_master_password\">\n        <span class=\"security-token\"></span>\n        <div id='loginMessage' class=\"message helptext\">Please enter your secret key passphrase</div>\n    </div>\n    <div class=\"submit-wrapper clearfix\">\n        <a id='loginSubmit' class=\"button primary big\">login</a>\n    </div>\n</div>"
  , __filename = "src/all/data/ejs/login/form.ejs";
try {
  var __output = [], __append = __output.push.bind(__output);
  with (locals || {}) {
    ; __append("<div class=\"page login-form master-password \">\n    <div class=\"input text required\">\n        <label for=\"UserUsername\">Username</label>\n        <input name=\"data[User][username]\" class=\"required fluid\" maxlength=\"50\" type=\"text\" id=\"UserUsername\"\n               required=\"required\"\n               value=\"\" disabled=\"disabled\"/>\n    </div>\n    <div class=\"input text required\">\n        <label for=\"js_master_password\">Master password</label>\n        <input type=\"password\" placeholder=\"password\" id=\"js_master_password\">\n        <span class=\"security-token\"></span>\n        <div id='loginMessage' class=\"message helptext\">Please enter your secret key passphrase</div>\n    </div>\n    <div class=\"submit-wrapper clearfix\">\n        <a id='loginSubmit' class=\"button primary big\">login</a>\n    </div>\n</div>")
    ; __line = 17
  }
  return __output.join("");
} catch (e) {
  rethrow(e, __lines, __filename, __line, escapeFn);
}

}
},{}],7:[function(require,module,exports){
module.exports = function(locals, escapeFn, include, rethrow
/**/) {
rethrow = rethrow || function rethrow(err, str, flnm, lineno, esc){
  var lines = str.split('\n');
  var start = Math.max(lineno - 3, 0);
  var end = Math.min(lines.length, lineno + 3);
  var filename = esc(flnm); // eslint-disable-line
  // Error context
  var context = lines.slice(start, end).map(function (line, i){
    var curr = i + start + 1;
    return (curr == lineno ? ' >> ' : '    ')
      + curr
      + '| '
      + line;
  }).join('\n');

  // Alter exception message
  err.path = filename;
  err.message = (filename || 'ejs') + ':'
    + lineno + '\n'
    + context + '\n\n'
    + err.message;

  throw err;
};
escapeFn = escapeFn || function (markup) {
  return markup == undefined
    ? ''
    : String(markup)
        .replace(_MATCH_HTML, encode_char);
};
var _ENCODE_HTML_RULES = {
      "&": "&amp;"
    , "<": "&lt;"
    , ">": "&gt;"
    , '"': "&#34;"
    , "'": "&#39;"
    }
  , _MATCH_HTML = /[&<>'"]/g;
function encode_char(c) {
  return _ENCODE_HTML_RULES[c] || c;
};
;
var __line = 1
  , __lines = "<div class=\"message\"><?= passboltDomain ?></div>"
  , __filename = "src/all/data/ejs/login/message.ejs";
try {
  var __output = [], __append = __output.push.bind(__output);
  with (locals || {}) {
    ; __append("<div class=\"message\">")
    ; __append(escapeFn( passboltDomain ))
    ; __append("</div>")
  }
  return __output.join("");
} catch (e) {
  rethrow(e, __lines, __filename, __line, escapeFn);
}

}
},{}],8:[function(require,module,exports){
module.exports = function(locals, escapeFn, include, rethrow
/**/) {
rethrow = rethrow || function rethrow(err, str, flnm, lineno, esc){
  var lines = str.split('\n');
  var start = Math.max(lineno - 3, 0);
  var end = Math.min(lines.length, lineno + 3);
  var filename = esc(flnm); // eslint-disable-line
  // Error context
  var context = lines.slice(start, end).map(function (line, i){
    var curr = i + start + 1;
    return (curr == lineno ? ' >> ' : '    ')
      + curr
      + '| '
      + line;
  }).join('\n');

  // Alter exception message
  err.path = filename;
  err.message = (filename || 'ejs') + ':'
    + lineno + '\n'
    + context + '\n\n'
    + err.message;

  throw err;
};
escapeFn = escapeFn || function (markup) {
  return markup == undefined
    ? ''
    : String(markup)
        .replace(_MATCH_HTML, encode_char);
};
var _ENCODE_HTML_RULES = {
      "&": "&amp;"
    , "<": "&lt;"
    , ">": "&gt;"
    , '"': "&#34;"
    , "'": "&#39;"
    }
  , _MATCH_HTML = /[&<>'"]/g;
function encode_char(c) {
  return _ENCODE_HTML_RULES[c] || c;
};
;
var __line = 1
  , __lines = "<div class=\"col6 push1 information\">\n    <h2>Almost there, please register!</h2>\n    <div class=\"plugin-check-wrapper\">\n        <div class=\"plugin-check <?= browserName ?> warning\">\n            <p class=\"message\">\n                The plugin is installed but not configured.\n                <? if(publicRegistration) { ?>\n                    <a href=\"<?= passboltDomain ?>/register\">Please register</a>,\n                <? } else { ?>\n                    Please contact your domain administrator to request an invitation,\n\t\t\t\t<? } ?>\n                or <a href=\"<?= passboltDomain ?>/recover\">recover your account if you already have one!</a>\n            </p>\n        </div>\n    </div>\n    <p>\n        If you already registered please check your mail inbox (and your spam folder).\n    </p>\n</div>\n<div class=\"col4 push1 last\">\n\t<div class=\"logo\">\n\t\t<h1><span>Passbolt</span></h1>\n\t</div>\n    <div class=\"users login form\">\n        <div class=\"feedback\">\n            <i class=\"fa huge fa-rocket\" ></i>\n            <p>You need an account to login.</p>\n        </div>\n        <div class=\"actions-wrapper center\">\n\t\t\t<? if(publicRegistration) { ?>\n                <a class=\"button primary\" href=\"<?= passboltDomain ?>/register\">Register</a>\n                <a href=\"<?= passboltDomain ?>/recover\">Have an account?</a>\n\t\t\t<? } else { ?>\n                Please contact your domain administrator to request an invitation.<br><br>\n                or <a href=\"<?= passboltDomain ?>/recover\">recover your existing account</a>\n\t\t\t<? } ?>\n        </div>\n    </div>\n</div>\n"
  , __filename = "src/all/data/ejs/login/noconfig.ejs";
try {
  var __output = [], __append = __output.push.bind(__output);
  with (locals || {}) {
    ; __append("<div class=\"col6 push1 information\">\n    <h2>Almost there, please register!</h2>\n    <div class=\"plugin-check-wrapper\">\n        <div class=\"plugin-check ")
    ; __line = 4
    ; __append(escapeFn( browserName ))
    ; __append(" warning\">\n            <p class=\"message\">\n                The plugin is installed but not configured.\n                ")
    ; __line = 7
    ;  if(publicRegistration) { 
    ; __append("\n                    <a href=\"")
    ; __line = 8
    ; __append(escapeFn( passboltDomain ))
    ; __append("/register\">Please register</a>,\n                ")
    ; __line = 9
    ;  } else { 
    ; __append("\n                    Please contact your domain administrator to request an invitation,\n				")
    ; __line = 11
    ;  } 
    ; __append("\n                or <a href=\"")
    ; __line = 12
    ; __append(escapeFn( passboltDomain ))
    ; __append("/recover\">recover your account if you already have one!</a>\n            </p>\n        </div>\n    </div>\n    <p>\n        If you already registered please check your mail inbox (and your spam folder).\n    </p>\n</div>\n<div class=\"col4 push1 last\">\n	<div class=\"logo\">\n		<h1><span>Passbolt</span></h1>\n	</div>\n    <div class=\"users login form\">\n        <div class=\"feedback\">\n            <i class=\"fa huge fa-rocket\" ></i>\n            <p>You need an account to login.</p>\n        </div>\n        <div class=\"actions-wrapper center\">\n			")
    ; __line = 30
    ;  if(publicRegistration) { 
    ; __append("\n                <a class=\"button primary\" href=\"")
    ; __line = 31
    ; __append(escapeFn( passboltDomain ))
    ; __append("/register\">Register</a>\n                <a href=\"")
    ; __line = 32
    ; __append(escapeFn( passboltDomain ))
    ; __append("/recover\">Have an account?</a>\n			")
    ; __line = 33
    ;  } else { 
    ; __append("\n                Please contact your domain administrator to request an invitation.<br><br>\n                or <a href=\"")
    ; __line = 35
    ; __append(escapeFn( passboltDomain ))
    ; __append("/recover\">recover your existing account</a>\n			")
    ; __line = 36
    ;  } 
    ; __append("\n        </div>\n    </div>\n</div>\n")
    ; __line = 40
  }
  return __output.join("");
} catch (e) {
  rethrow(e, __lines, __filename, __line, escapeFn);
}

}
},{}],9:[function(require,module,exports){
module.exports = function(locals, escapeFn, include, rethrow
/**/) {
rethrow = rethrow || function rethrow(err, str, flnm, lineno, esc){
  var lines = str.split('\n');
  var start = Math.max(lineno - 3, 0);
  var end = Math.min(lines.length, lineno + 3);
  var filename = esc(flnm); // eslint-disable-line
  // Error context
  var context = lines.slice(start, end).map(function (line, i){
    var curr = i + start + 1;
    return (curr == lineno ? ' >> ' : '    ')
      + curr
      + '| '
      + line;
  }).join('\n');

  // Alter exception message
  err.path = filename;
  err.message = (filename || 'ejs') + ':'
    + lineno + '\n'
    + context + '\n\n'
    + err.message;

  throw err;
};
escapeFn = escapeFn || function (markup) {
  return markup == undefined
    ? ''
    : String(markup)
        .replace(_MATCH_HTML, encode_char);
};
var _ENCODE_HTML_RULES = {
      "&": "&amp;"
    , "<": "&lt;"
    , ">": "&gt;"
    , '"': "&#34;"
    , "'": "&#39;"
    }
  , _MATCH_HTML = /[&<>'"]/g;
function encode_char(c) {
  return _ENCODE_HTML_RULES[c] || c;
};
;
var __line = 1
  , __lines = "<div class=\"col6 push1 information\">\n    <h2>Welcome back!</h2>\n    <div class=\"plugin-check-wrapper\">\n        <div class=\"plugin-check <?= browserName ?> success\">\n            <p class=\"message\">\n                Nice one! The plugin is installed and configured. You are good to go!\n            </p>\n        </div>\n    </div>\n    <div class=\"plugin-check-wrapper\">\n        <div class=\"plugin-check gpg notice\">\n            <p class=\"message\">\n                Server identity check in progress...\n                Checking key:\n                <a href=\"auth/verify\" target='_blank' id=\"serverkey_id\">\n                   <?= serverKeyId ?>\n                </a>\n            </p>\n        </div>\n    </div>\n</div>\n<div class=\"col4 push1 last\">\n    <div class=\"logo\">\n        <h1><span>Passbolt</span></h1>\n    </div>\n    <div class=\"users login form\">\n        <div class=\"feedback\">\n            <i class=\"fa fa-cog fa-spin huge\" ></i>\n            <p>Checking server key<br> please wait...</p>\n        </div>\n    </div>\n</div>\n"
  , __filename = "src/all/data/ejs/login/stage0.ejs";
try {
  var __output = [], __append = __output.push.bind(__output);
  with (locals || {}) {
    ; __append("<div class=\"col6 push1 information\">\n    <h2>Welcome back!</h2>\n    <div class=\"plugin-check-wrapper\">\n        <div class=\"plugin-check ")
    ; __line = 4
    ; __append(escapeFn( browserName ))
    ; __append(" success\">\n            <p class=\"message\">\n                Nice one! The plugin is installed and configured. You are good to go!\n            </p>\n        </div>\n    </div>\n    <div class=\"plugin-check-wrapper\">\n        <div class=\"plugin-check gpg notice\">\n            <p class=\"message\">\n                Server identity check in progress...\n                Checking key:\n                <a href=\"auth/verify\" target='_blank' id=\"serverkey_id\">\n                   ")
    ; __line = 16
    ; __append(escapeFn( serverKeyId ))
    ; __append("\n                </a>\n            </p>\n        </div>\n    </div>\n</div>\n<div class=\"col4 push1 last\">\n    <div class=\"logo\">\n        <h1><span>Passbolt</span></h1>\n    </div>\n    <div class=\"users login form\">\n        <div class=\"feedback\">\n            <i class=\"fa fa-cog fa-spin huge\" ></i>\n            <p>Checking server key<br> please wait...</p>\n        </div>\n    </div>\n</div>\n")
    ; __line = 33
  }
  return __output.join("");
} catch (e) {
  rethrow(e, __lines, __filename, __line, escapeFn);
}

}
},{}],10:[function(require,module,exports){
module.exports = function(locals, escapeFn, include, rethrow
/**/) {
rethrow = rethrow || function rethrow(err, str, flnm, lineno, esc){
  var lines = str.split('\n');
  var start = Math.max(lineno - 3, 0);
  var end = Math.min(lines.length, lineno + 3);
  var filename = esc(flnm); // eslint-disable-line
  // Error context
  var context = lines.slice(start, end).map(function (line, i){
    var curr = i + start + 1;
    return (curr == lineno ? ' >> ' : '    ')
      + curr
      + '| '
      + line;
  }).join('\n');

  // Alter exception message
  err.path = filename;
  err.message = (filename || 'ejs') + ':'
    + lineno + '\n'
    + context + '\n\n'
    + err.message;

  throw err;
};
escapeFn = escapeFn || function (markup) {
  return markup == undefined
    ? ''
    : String(markup)
        .replace(_MATCH_HTML, encode_char);
};
var _ENCODE_HTML_RULES = {
      "&": "&amp;"
    , "<": "&lt;"
    , ">": "&gt;"
    , '"': "&#34;"
    , "'": "&#39;"
    }
  , _MATCH_HTML = /[&<>'"]/g;
function encode_char(c) {
  return _ENCODE_HTML_RULES[c] || c;
};
;
var __line = 1
  , __lines = "<div class=\"col6 push1 information\">\n    <h2>This domain is not known!</h2>\n    <div class=\"plugin-check-wrapper\">\n        <div class=\"plugin-check <?= browserName ?> warning\">\n            <p class=\"message\">\n                The plugin is installed but is already configured for another domain :<br>\n            \t<a href=\"<?= trustedDomain ?>\" class=\"trusteddomain\"><?= trustedDomain ?></a><br>\n            </p>\n        </div>\n    </div>\n    <p>You can <a href=\"<?= passboltDomain ?>/register\">register again</a> for this domain\n        or <a href=\"<?= passboltDomain ?>/recover\"> recover an existing account</a>,\n        but you will lose your account on the existing domain. Proceed with caution.</p>\n</div>\n<div class=\"col4 push1 last\">\n    <div class=\"logo\">\n        <h1><a href=\"#\"><span>Passbolt</span></a></h1>\n    </div>\n    <div class=\"users login form\">\n        <div class=\"feedback\">\n            <i class=\"fa huge fa-globe\" ></i>\n            <p>Chrome plugin is not configured to work with this domain</p>\n        </div>\n        <div class=\"actions-wrapper center\">\n            <? if(publicRegistration) { ?>\n                <a class=\"button primary big\" href=\"<?= passboltDomain ?>/register\">Register for this domain</a><br><br>\n            <? } ?>\n            <a href=\"<?= passboltDomain ?>/recover\">or recover an existing account</a>\n        </div>\n    </div>\n</div>"
  , __filename = "src/all/data/ejs/login/wrongDomain.ejs";
try {
  var __output = [], __append = __output.push.bind(__output);
  with (locals || {}) {
    ; __append("<div class=\"col6 push1 information\">\n    <h2>This domain is not known!</h2>\n    <div class=\"plugin-check-wrapper\">\n        <div class=\"plugin-check ")
    ; __line = 4
    ; __append(escapeFn( browserName ))
    ; __append(" warning\">\n            <p class=\"message\">\n                The plugin is installed but is already configured for another domain :<br>\n            	<a href=\"")
    ; __line = 7
    ; __append(escapeFn( trustedDomain ))
    ; __append("\" class=\"trusteddomain\">")
    ; __append(escapeFn( trustedDomain ))
    ; __append("</a><br>\n            </p>\n        </div>\n    </div>\n    <p>You can <a href=\"")
    ; __line = 11
    ; __append(escapeFn( passboltDomain ))
    ; __append("/register\">register again</a> for this domain\n        or <a href=\"")
    ; __line = 12
    ; __append(escapeFn( passboltDomain ))
    ; __append("/recover\"> recover an existing account</a>,\n        but you will lose your account on the existing domain. Proceed with caution.</p>\n</div>\n<div class=\"col4 push1 last\">\n    <div class=\"logo\">\n        <h1><a href=\"#\"><span>Passbolt</span></a></h1>\n    </div>\n    <div class=\"users login form\">\n        <div class=\"feedback\">\n            <i class=\"fa huge fa-globe\" ></i>\n            <p>Chrome plugin is not configured to work with this domain</p>\n        </div>\n        <div class=\"actions-wrapper center\">\n            ")
    ; __line = 25
    ;  if(publicRegistration) { 
    ; __append("\n                <a class=\"button primary big\" href=\"")
    ; __line = 26
    ; __append(escapeFn( passboltDomain ))
    ; __append("/register\">Register for this domain</a><br><br>\n            ")
    ; __line = 27
    ;  } 
    ; __append("\n            <a href=\"")
    ; __line = 28
    ; __append(escapeFn( passboltDomain ))
    ; __append("/recover\">or recover an existing account</a>\n        </div>\n    </div>\n</div>")
    ; __line = 31
  }
  return __output.join("");
} catch (e) {
  rethrow(e, __lines, __filename, __line, escapeFn);
}

}
},{}]},{},[1]);
