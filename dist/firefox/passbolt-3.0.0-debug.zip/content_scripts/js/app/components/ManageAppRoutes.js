/**
 * Passbolt ~ Open source password manager for teams
 * Copyright (c) 2020 Passbolt SA (https://www.passbolt.com)
 *
 * Licensed under GNU Affero General Public License version 3 of the or any later version.
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) 2020 Passbolt SA (https://www.passbolt.com)
 * @license       https://opensource.org/licenses/AGPL-3.0 AGPL License
 * @link          https://www.passbolt.com Passbolt(tm)
 * @since        3.0.0
 */
import React, {Component} from "react";
import {withRouter} from "react-router-dom";

class ManageAppRoutes extends Component{
  componentDidMount() {
    port.on('passbolt.location.change', (pathname) => {
      this.props.history.push(pathname);
      if (pathname === "/app/administration") {
        document.location.href = "http://passbolt.local/app/administration";
      }
    });

    // window.onpopstate = function(pop) {
    //   console.log('on popstate', pop)
    // };
    // this.props.history.listen((location, action) => {
    //   port.emit('internal history change', location.pathname);
    // });
    // window.addEventListener('locationchange', function(){
    //   console.log('location changed!');
    // })

    //@todo dirty as fuck, but it can catch canjs silent location changes.
    let prevPathname = window.location.pathname;
    const _this = this;
    setInterval(function() {
      if (prevPathname !== window.location.pathname) {
        console.log('url changed to', window.location.pathname);
        prevPathname = window.location.pathname;
        _this.props.history.push(window.location.pathname);
      }
    }, 1000);
  }

  render() {
    return (
      <></>
    );
  }
}

export default withRouter(ManageAppRoutes);