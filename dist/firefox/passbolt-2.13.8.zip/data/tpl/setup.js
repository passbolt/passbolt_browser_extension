(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
window.templates = window.templates || {};
window.templates.setup = window.templates.setup || {};
window.templates.setup.action_buttons = require('./setup/action_buttons.js');
window.templates.setup.already_configured = require('./setup/already_configured.js');
window.templates.setup.backup_key = require('./setup/backup_key.js');
window.templates.setup.define_key = require('./setup/define_key.js');
window.templates.setup.dialog_key_info = require('./setup/dialog_key_info.js');
window.templates.setup.domain_check = require('./setup/domain_check.js');
window.templates.setup.fatal_error = require('./setup/fatal_error.js');
window.templates.setup.generate_key = require('./setup/generate_key.js');
window.templates.setup.import_key_recover_info = require('./setup/import_key_recover_info.js');
window.templates.setup.import_key = require('./setup/import_key.js');
window.templates.setup.key_info = require('./setup/key_info.js');
window.templates.setup.login_redirection = require('./setup/login_redirection.js');
window.templates.setup.menu = require('./setup/menu.js');
window.templates.setup.secret = require('./setup/secret.js');
window.templates.setup.security_token = require('./setup/security_token.js');

},{"./setup/action_buttons.js":2,"./setup/already_configured.js":3,"./setup/backup_key.js":4,"./setup/define_key.js":5,"./setup/dialog_key_info.js":6,"./setup/domain_check.js":7,"./setup/fatal_error.js":8,"./setup/generate_key.js":9,"./setup/import_key.js":10,"./setup/import_key_recover_info.js":11,"./setup/key_info.js":12,"./setup/login_redirection.js":13,"./setup/menu.js":14,"./setup/secret.js":15,"./setup/security_token.js":16}],2:[function(require,module,exports){
module.exports = function(locals, escapeFn, include, rethrow
) {
rethrow = rethrow || function rethrow(err, str, flnm, lineno, esc){
  var lines = str.split('\n');
  var start = Math.max(lineno - 3, 0);
  var end = Math.min(lines.length, lineno + 3);
  var filename = esc(flnm); // eslint-disable-line
  // Error context
  var context = lines.slice(start, end).map(function (line, i){
    var curr = i + start + 1;
    return (curr == lineno ? ' >> ' : '    ')
      + curr
      + '| '
      + line;
  }).join('\n');

  // Alter exception message
  err.path = filename;
  err.message = (filename || 'ejs') + ':'
    + lineno + '\n'
    + context + '\n\n'
    + err.message;

  throw err;
};
escapeFn = escapeFn || function (markup) {
  return markup == undefined
    ? ''
    : String(markup)
      .replace(_MATCH_HTML, encode_char);
};
var _ENCODE_HTML_RULES = {
      "&": "&amp;"
    , "<": "&lt;"
    , ">": "&gt;"
    , '"': "&#34;"
    , "'": "&#39;"
    }
  , _MATCH_HTML = /[&<>'"]/g;
function encode_char(c) {
  return _ENCODE_HTML_RULES[c] || c;
};
;
var __line = 1
  , __lines = "<div class=\"submit-input-wrapper\">\n    <a id=\"js_setup_cancel_step\" class=\"button cancel big\">Cancel</a>\n    <a id=\"js_setup_submit_step\" class=\"button primary big\">Next</a>\n</div>\n"
  , __filename = "src/all/data/ejs/setup/action_buttons.ejs";
try {
  var __output = "";
  function __append(s) { if (s !== undefined && s !== null) __output += s }
  with (locals || {}) {
    ; __append("<div class=\"submit-input-wrapper\">\n    <a id=\"js_setup_cancel_step\" class=\"button cancel big\">Cancel</a>\n    <a id=\"js_setup_submit_step\" class=\"button primary big\">Next</a>\n</div>\n")
    ; __line = 5
  }
  return __output;
} catch (e) {
  rethrow(e, __lines, __filename, __line, escapeFn);
}

//# sourceURL=src/all/data/ejs/setup/action_buttons.ejs

}
},{}],3:[function(require,module,exports){
module.exports = function(locals, escapeFn, include, rethrow
) {
rethrow = rethrow || function rethrow(err, str, flnm, lineno, esc){
  var lines = str.split('\n');
  var start = Math.max(lineno - 3, 0);
  var end = Math.min(lines.length, lineno + 3);
  var filename = esc(flnm); // eslint-disable-line
  // Error context
  var context = lines.slice(start, end).map(function (line, i){
    var curr = i + start + 1;
    return (curr == lineno ? ' >> ' : '    ')
      + curr
      + '| '
      + line;
  }).join('\n');

  // Alter exception message
  err.path = filename;
  err.message = (filename || 'ejs') + ':'
    + lineno + '\n'
    + context + '\n\n'
    + err.message;

  throw err;
};
escapeFn = escapeFn || function (markup) {
  return markup == undefined
    ? ''
    : String(markup)
      .replace(_MATCH_HTML, encode_char);
};
var _ENCODE_HTML_RULES = {
      "&": "&amp;"
    , "<": "&lt;"
    , ">": "&gt;"
    , '"': "&#34;"
    , "'": "&#39;"
    }
  , _MATCH_HTML = /[&<>'"]/g;
function encode_char(c) {
  return _ENCODE_HTML_RULES[c] || c;
};
;
var __line = 1
  , __lines = "<strong>Warning:</strong> The plugin is already configured for <?= firstname ?> <?= lastname ?> (<?= username ?>), on domain <?= domain ?>.\nCompleting this setup again will prevent <?= firstname ?> <?= lastname ?> from accesssing their passbolt account with this browser.\n"
  , __filename = "src/all/data/ejs/setup/already_configured.ejs";
try {
  var __output = "";
  function __append(s) { if (s !== undefined && s !== null) __output += s }
  with (locals || {}) {
    ; __append("<strong>Warning:</strong> The plugin is already configured for ")
    ; __append(escapeFn( firstname ))
    ; __append(" ")
    ; __append(escapeFn( lastname ))
    ; __append(" (")
    ; __append(escapeFn( username ))
    ; __append("), on domain ")
    ; __append(escapeFn( domain ))
    ; __append(".\nCompleting this setup again will prevent ")
    ; __line = 2
    ; __append(escapeFn( firstname ))
    ; __append(" ")
    ; __append(escapeFn( lastname ))
    ; __append(" from accesssing their passbolt account with this browser.\n")
    ; __line = 3
  }
  return __output;
} catch (e) {
  rethrow(e, __lines, __filename, __line, escapeFn);
}

//# sourceURL=src/all/data/ejs/setup/already_configured.ejs

}
},{}],4:[function(require,module,exports){
module.exports = function(locals, escapeFn, include, rethrow
) {
rethrow = rethrow || function rethrow(err, str, flnm, lineno, esc){
  var lines = str.split('\n');
  var start = Math.max(lineno - 3, 0);
  var end = Math.min(lines.length, lineno + 3);
  var filename = esc(flnm); // eslint-disable-line
  // Error context
  var context = lines.slice(start, end).map(function (line, i){
    var curr = i + start + 1;
    return (curr == lineno ? ' >> ' : '    ')
      + curr
      + '| '
      + line;
  }).join('\n');

  // Alter exception message
  err.path = filename;
  err.message = (filename || 'ejs') + ':'
    + lineno + '\n'
    + context + '\n\n'
    + err.message;

  throw err;
};
escapeFn = escapeFn || function (markup) {
  return markup == undefined
    ? ''
    : String(markup)
      .replace(_MATCH_HTML, encode_char);
};
var _ENCODE_HTML_RULES = {
      "&": "&amp;"
    , "<": "&lt;"
    , ">": "&gt;"
    , '"': "&#34;"
    , "'": "&#39;"
    }
  , _MATCH_HTML = /[&<>'"]/g;
function encode_char(c) {
  return _ENCODE_HTML_RULES[c] || c;
};
;
var __line = 1
  , __lines = "<div class=\"col7\">\n    <div class=\"plugin-check-wrapper\">\n        <h3>Let's make a backup</h3>\n        <p>All good! The secret key is stored in your add-on and ready to use.</p>\n        <div class=\"success message backup-prompt\">\n            <a id=\"js_backup_key_download\" class=\"button primary next big\">\n                <i class=\"fa fa-fw fa-download\"></i>\n                <span>download</span>\n            </a>\n            <span class=\"help-text\">Take some time to make a backup of your key (and store it in a safe location).</span>\n        </div>\n        <p>\n            You should always make a backup. If you lose this key (by breaking or losing your computer\n            and not having a backup for example), your encrypted data will be lost even if you remember\n            your passphrase.\n        </p>\n    </div>\n</div>\n<div class=\"col4 last\">\n    <h3>Pro tips</h3>\n    <p>\n        The secret key is itself encrypted, so it is only usable if one knows the passphrase.<br><br>\n        It is a good practice to store a backup in a different location.\n        You can, for example, print it and mail it to a family member (along with a nice postcard!) and ask them to keep it somewhere safe.\n        <br><br>\n        Or, even better, you can store it in a safe if you have one!\n    </p>\n</div>"
  , __filename = "src/all/data/ejs/setup/backup_key.ejs";
try {
  var __output = "";
  function __append(s) { if (s !== undefined && s !== null) __output += s }
  with (locals || {}) {
    ; __append("<div class=\"col7\">\n    <div class=\"plugin-check-wrapper\">\n        <h3>Let's make a backup</h3>\n        <p>All good! The secret key is stored in your add-on and ready to use.</p>\n        <div class=\"success message backup-prompt\">\n            <a id=\"js_backup_key_download\" class=\"button primary next big\">\n                <i class=\"fa fa-fw fa-download\"></i>\n                <span>download</span>\n            </a>\n            <span class=\"help-text\">Take some time to make a backup of your key (and store it in a safe location).</span>\n        </div>\n        <p>\n            You should always make a backup. If you lose this key (by breaking or losing your computer\n            and not having a backup for example), your encrypted data will be lost even if you remember\n            your passphrase.\n        </p>\n    </div>\n</div>\n<div class=\"col4 last\">\n    <h3>Pro tips</h3>\n    <p>\n        The secret key is itself encrypted, so it is only usable if one knows the passphrase.<br><br>\n        It is a good practice to store a backup in a different location.\n        You can, for example, print it and mail it to a family member (along with a nice postcard!) and ask them to keep it somewhere safe.\n        <br><br>\n        Or, even better, you can store it in a safe if you have one!\n    </p>\n</div>")
    ; __line = 28
  }
  return __output;
} catch (e) {
  rethrow(e, __lines, __filename, __line, escapeFn);
}

//# sourceURL=src/all/data/ejs/setup/backup_key.ejs

}
},{}],5:[function(require,module,exports){
module.exports = function(locals, escapeFn, include, rethrow
) {
rethrow = rethrow || function rethrow(err, str, flnm, lineno, esc){
  var lines = str.split('\n');
  var start = Math.max(lineno - 3, 0);
  var end = Math.min(lines.length, lineno + 3);
  var filename = esc(flnm); // eslint-disable-line
  // Error context
  var context = lines.slice(start, end).map(function (line, i){
    var curr = i + start + 1;
    return (curr == lineno ? ' >> ' : '    ')
      + curr
      + '| '
      + line;
  }).join('\n');

  // Alter exception message
  err.path = filename;
  err.message = (filename || 'ejs') + ':'
    + lineno + '\n'
    + context + '\n\n'
    + err.message;

  throw err;
};
escapeFn = escapeFn || function (markup) {
  return markup == undefined
    ? ''
    : String(markup)
      .replace(_MATCH_HTML, encode_char);
};
var _ENCODE_HTML_RULES = {
      "&": "&amp;"
    , "<": "&lt;"
    , ">": "&gt;"
    , '"': "&#34;"
    , "'": "&#39;"
    }
  , _MATCH_HTML = /[&<>'"]/g;
function encode_char(c) {
  return _ENCODE_HTML_RULES[c] || c;
};
;
var __line = 1
  , __lines = "<div class=\"col10 last feedback\">\n    <p class=\"message error hidden\" id=\"js_main_error_feedback\"></p>\n</div>\n<!-- left collumn -->\n<div class=\"col6\">\n    <h3>Create a new key</h3>\n    <div class=\"input text required disabled\">\n        <label for=\"OwnerName\">Owner Name</label>\n        <input name=\"data[Owner][name]\" class=\"required fluid\" id=\"OwnerName\" required=\"required\" type=\"text\" disabled=\"disabled\" value=\"<?= firstName ?> <?= lastName ?>\">\n    </div>\n    <div class=\"input text required disabled\">\n        <label for=\"OwnerEmail\">Owner Email</label>\n        <input name=\"data[Owner][email]\" class=\"required fluid\" id=\"OwnerEmail\" required=\"required\" type=\"text\" disabled=\"disabled\" value=\"<?= username ?>\">\n    </div>\n    <div class=\"input text\">\n        <label for=\"KeyComment\">Comment</label>\n        <input name=\"data[Key][comment]\" class=\"required fluid\" id=\"KeyComment\" required=\"required\" type=\"text\" placeholder=\"add a comment (optional)\" value=\"<?= comment ?>\">\n    </div>\n</div>\n\n<!-- right collumn -->\n<div class=\"col4 last\">\n    <h3>Advanced settings</h3>\n    <div class=\"input select required\">\n        <label for=\"KeyType\">Key Type</label>\n        <select name=\"data[Key][type]\" id=\"KeyType\" disabled=\"disabled\" class=\"fluid\">\n            <option value=\"RSA-DSA\" >RSA and DSA (default)</option>\n            <option value=\"DSA-EL\" >DSA and Elgamal</option>\n        </select>\n    </div>\n    <div class=\"input select required\">\n        <label for=\"KeyLength\">Key Length</label>\n        <select name=\"data[Key][length]\" id=\"KeyLength\" disabled=\"disabled\" class=\"fluid\">\n            <option value=\"1024\" >1024</option>\n            <option value=\"2048\" >2048</option>\n            <option value=\"3076\" >3076</option>\n        </select>\n    </div>\n\n    <div class=\"input date\">\n        <label for=\"KeyExpire\">Key Expire</label>\n        <input name=\"data[Key][expire]\" class=\"required fluid\" id=\"KeyExpire\" disabled=\"disabled\" required=\"required\" placeholder=\"dd/mm/yyyy\" type=\"text\">\n        <span class=\"input-addon\"><i class=\"fa fa-calendar fa-fw\"></i></span>\n    </div>\n</div>"
  , __filename = "src/all/data/ejs/setup/define_key.ejs";
try {
  var __output = "";
  function __append(s) { if (s !== undefined && s !== null) __output += s }
  with (locals || {}) {
    ; __append("<div class=\"col10 last feedback\">\n    <p class=\"message error hidden\" id=\"js_main_error_feedback\"></p>\n</div>\n<!-- left collumn -->\n<div class=\"col6\">\n    <h3>Create a new key</h3>\n    <div class=\"input text required disabled\">\n        <label for=\"OwnerName\">Owner Name</label>\n        <input name=\"data[Owner][name]\" class=\"required fluid\" id=\"OwnerName\" required=\"required\" type=\"text\" disabled=\"disabled\" value=\"")
    ; __line = 9
    ; __append(escapeFn( firstName ))
    ; __append(" ")
    ; __append(escapeFn( lastName ))
    ; __append("\">\n    </div>\n    <div class=\"input text required disabled\">\n        <label for=\"OwnerEmail\">Owner Email</label>\n        <input name=\"data[Owner][email]\" class=\"required fluid\" id=\"OwnerEmail\" required=\"required\" type=\"text\" disabled=\"disabled\" value=\"")
    ; __line = 13
    ; __append(escapeFn( username ))
    ; __append("\">\n    </div>\n    <div class=\"input text\">\n        <label for=\"KeyComment\">Comment</label>\n        <input name=\"data[Key][comment]\" class=\"required fluid\" id=\"KeyComment\" required=\"required\" type=\"text\" placeholder=\"add a comment (optional)\" value=\"")
    ; __line = 17
    ; __append(escapeFn( comment ))
    ; __append("\">\n    </div>\n</div>\n\n<!-- right collumn -->\n<div class=\"col4 last\">\n    <h3>Advanced settings</h3>\n    <div class=\"input select required\">\n        <label for=\"KeyType\">Key Type</label>\n        <select name=\"data[Key][type]\" id=\"KeyType\" disabled=\"disabled\" class=\"fluid\">\n            <option value=\"RSA-DSA\" >RSA and DSA (default)</option>\n            <option value=\"DSA-EL\" >DSA and Elgamal</option>\n        </select>\n    </div>\n    <div class=\"input select required\">\n        <label for=\"KeyLength\">Key Length</label>\n        <select name=\"data[Key][length]\" id=\"KeyLength\" disabled=\"disabled\" class=\"fluid\">\n            <option value=\"1024\" >1024</option>\n            <option value=\"2048\" >2048</option>\n            <option value=\"3076\" >3076</option>\n        </select>\n    </div>\n\n    <div class=\"input date\">\n        <label for=\"KeyExpire\">Key Expire</label>\n        <input name=\"data[Key][expire]\" class=\"required fluid\" id=\"KeyExpire\" disabled=\"disabled\" required=\"required\" placeholder=\"dd/mm/yyyy\" type=\"text\">\n        <span class=\"input-addon\"><i class=\"fa fa-calendar fa-fw\"></i></span>\n    </div>\n</div>")
    ; __line = 45
  }
  return __output;
} catch (e) {
  rethrow(e, __lines, __filename, __line, escapeFn);
}

//# sourceURL=src/all/data/ejs/setup/define_key.ejs

}
},{}],6:[function(require,module,exports){
module.exports = function(locals, escapeFn, include, rethrow
) {
rethrow = rethrow || function rethrow(err, str, flnm, lineno, esc){
  var lines = str.split('\n');
  var start = Math.max(lineno - 3, 0);
  var end = Math.min(lines.length, lineno + 3);
  var filename = esc(flnm); // eslint-disable-line
  // Error context
  var context = lines.slice(start, end).map(function (line, i){
    var curr = i + start + 1;
    return (curr == lineno ? ' >> ' : '    ')
      + curr
      + '| '
      + line;
  }).join('\n');

  // Alter exception message
  err.path = filename;
  err.message = (filename || 'ejs') + ':'
    + lineno + '\n'
    + context + '\n\n'
    + err.message;

  throw err;
};
escapeFn = escapeFn || function (markup) {
  return markup == undefined
    ? ''
    : String(markup)
      .replace(_MATCH_HTML, encode_char);
};
var _ENCODE_HTML_RULES = {
      "&": "&amp;"
    , "<": "&lt;"
    , ">": "&gt;"
    , '"': "&#34;"
    , "'": "&#39;"
    }
  , _MATCH_HTML = /[&<>'"]/g;
function encode_char(c) {
  return _ENCODE_HTML_RULES[c] || c;
};
;
var __line = 1
  , __lines = "<div class=\"dialog-wrapper\">\n    <div class=\"dialog medium key-info\" id=\"dialog-server-key-info\">\n        <div class=\"dialog-header\">\n            <h2>Please verify the server key</h2>\n            <a class=\"dialog-close js-dialog-close\">\n                <i class=\"fa fa-close\"></i>\n                <span class=\"visuallyhidden\">close</span>\n            </a>\n        </div>\n        <div class=\"js_dialog_content dialog-content\">\n            <div class=\"form-content\">\n                <p>\n                    <strong>\n                        Check that the details of the GPG key below are valid. Do not hesitate to contact your support person in case of doubt!\n                    </strong>\n                </p>\n                <table>\n                    <tbody>\n                    <tr class=\"owner-name\">\n                        <td class=\"label\">Owner Name</td>\n                        <td class=\"value\"><?= userIds[0].name ?></td>\n                    </tr>\n                    <tr class=\"owner-email\">\n                        <td class=\"label\">Owner Email</td>\n                        <td class=\"value\"><?= userIds[0].email ?></td>\n                    </tr>\n                    <tr class=\"keyid\">\n                        <td class=\"label\">Key ID</td>\n                        <td class=\"value\">\n                            <? var kid = keyId.toUpperCase(); ?>\n                            <?= kid ?>\n                        </td>\n                    </tr>\n                    <tr class=\"fingerprint\">\n                        <td class=\"label\">Fingerprint</td>\n                        <td class=\"value\">\n                            <? var fgprt = fingerprint.toUpperCase(); ?>\n                            <?= fgprt ?>\n                        </td>\n                    </tr>\n                    <tr class=\"created\">\n                        <td class=\"label\">Created</td>\n                        <td class=\"value\">\n                            <?= created ?>\n                        </td>\n                    </tr>\n                    <tr class=\"expires\">\n                        <td class=\"label\">Expires</td>\n                        <td class=\"value\">\n                            <?= expires ?>\n                        </td>\n                    </tr>\n                    <tr class=\"length\">\n                        <td class=\"label\">Length</td>\n                        <td class=\"value\"><?= length ?></td>\n                    </tr>\n                    <tr class=\"algorithm\">\n                        <td class=\"label\">Algorithm</td>\n                        <td class=\"value\">\n                            <? var algo = algorithm.toUpperCase(); ?>\n                            <?= algo ?>\n                        </td>\n                    </tr>\n                    </tbody>\n                </table>\n            </div>\n\n            <div class=\"submit-wrapper clearfix\">\n                <input type=\"submit\" value=\"OK\" class=\"button primary\" id=\"key-info-ok\">\n                <!-- <a class=\"button\" id=\"js_keyinfo_help\">Help!</a> -->\n            </div>\n        </div>\n    </div>\n</div>"
  , __filename = "src/all/data/ejs/setup/dialog_key_info.ejs";
try {
  var __output = "";
  function __append(s) { if (s !== undefined && s !== null) __output += s }
  with (locals || {}) {
    ; __append("<div class=\"dialog-wrapper\">\n    <div class=\"dialog medium key-info\" id=\"dialog-server-key-info\">\n        <div class=\"dialog-header\">\n            <h2>Please verify the server key</h2>\n            <a class=\"dialog-close js-dialog-close\">\n                <i class=\"fa fa-close\"></i>\n                <span class=\"visuallyhidden\">close</span>\n            </a>\n        </div>\n        <div class=\"js_dialog_content dialog-content\">\n            <div class=\"form-content\">\n                <p>\n                    <strong>\n                        Check that the details of the GPG key below are valid. Do not hesitate to contact your support person in case of doubt!\n                    </strong>\n                </p>\n                <table>\n                    <tbody>\n                    <tr class=\"owner-name\">\n                        <td class=\"label\">Owner Name</td>\n                        <td class=\"value\">")
    ; __line = 21
    ; __append(escapeFn( userIds[0].name ))
    ; __append("</td>\n                    </tr>\n                    <tr class=\"owner-email\">\n                        <td class=\"label\">Owner Email</td>\n                        <td class=\"value\">")
    ; __line = 25
    ; __append(escapeFn( userIds[0].email ))
    ; __append("</td>\n                    </tr>\n                    <tr class=\"keyid\">\n                        <td class=\"label\">Key ID</td>\n                        <td class=\"value\">\n                            ")
    ; __line = 30
    ;  var kid = keyId.toUpperCase(); 
    ; __append("\n                            ")
    ; __line = 31
    ; __append(escapeFn( kid ))
    ; __append("\n                        </td>\n                    </tr>\n                    <tr class=\"fingerprint\">\n                        <td class=\"label\">Fingerprint</td>\n                        <td class=\"value\">\n                            ")
    ; __line = 37
    ;  var fgprt = fingerprint.toUpperCase(); 
    ; __append("\n                            ")
    ; __line = 38
    ; __append(escapeFn( fgprt ))
    ; __append("\n                        </td>\n                    </tr>\n                    <tr class=\"created\">\n                        <td class=\"label\">Created</td>\n                        <td class=\"value\">\n                            ")
    ; __line = 44
    ; __append(escapeFn( created ))
    ; __append("\n                        </td>\n                    </tr>\n                    <tr class=\"expires\">\n                        <td class=\"label\">Expires</td>\n                        <td class=\"value\">\n                            ")
    ; __line = 50
    ; __append(escapeFn( expires ))
    ; __append("\n                        </td>\n                    </tr>\n                    <tr class=\"length\">\n                        <td class=\"label\">Length</td>\n                        <td class=\"value\">")
    ; __line = 55
    ; __append(escapeFn( length ))
    ; __append("</td>\n                    </tr>\n                    <tr class=\"algorithm\">\n                        <td class=\"label\">Algorithm</td>\n                        <td class=\"value\">\n                            ")
    ; __line = 60
    ;  var algo = algorithm.toUpperCase(); 
    ; __append("\n                            ")
    ; __line = 61
    ; __append(escapeFn( algo ))
    ; __append("\n                        </td>\n                    </tr>\n                    </tbody>\n                </table>\n            </div>\n\n            <div class=\"submit-wrapper clearfix\">\n                <input type=\"submit\" value=\"OK\" class=\"button primary\" id=\"key-info-ok\">\n                <!-- <a class=\"button\" id=\"js_keyinfo_help\">Help!</a> -->\n            </div>\n        </div>\n    </div>\n</div>")
    ; __line = 74
  }
  return __output;
} catch (e) {
  rethrow(e, __lines, __filename, __line, escapeFn);
}

//# sourceURL=src/all/data/ejs/setup/dialog_key_info.ejs

}
},{}],7:[function(require,module,exports){
module.exports = function(locals, escapeFn, include, rethrow
) {
rethrow = rethrow || function rethrow(err, str, flnm, lineno, esc){
  var lines = str.split('\n');
  var start = Math.max(lineno - 3, 0);
  var end = Math.min(lines.length, lineno + 3);
  var filename = esc(flnm); // eslint-disable-line
  // Error context
  var context = lines.slice(start, end).map(function (line, i){
    var curr = i + start + 1;
    return (curr == lineno ? ' >> ' : '    ')
      + curr
      + '| '
      + line;
  }).join('\n');

  // Alter exception message
  err.path = filename;
  err.message = (filename || 'ejs') + ':'
    + lineno + '\n'
    + context + '\n\n'
    + err.message;

  throw err;
};
escapeFn = escapeFn || function (markup) {
  return markup == undefined
    ? ''
    : String(markup)
      .replace(_MATCH_HTML, encode_char);
};
var _ENCODE_HTML_RULES = {
      "&": "&amp;"
    , "<": "&lt;"
    , ">": "&gt;"
    , '"': "&#34;"
    , "'": "&#39;"
    }
  , _MATCH_HTML = /[&<>'"]/g;
function encode_char(c) {
  return _ENCODE_HTML_RULES[c] || c;
};
;
var __line = 1
  , __lines = "<div class=\"col7\">\n    <div class=\"plugin-check-wrapper\">\n        <h3>Plugin check</h3>\n        <div class=\"plugin-check <?= browserName ?> success\">\n            <p class=\"message\">Nice one! The plugin is installed and up to date. You are good to go!</p>\n        </div>\n    </div>\n    <div class=\"why-plugin-wrapper\">\n        <h3>Url Check</h3>\n        <p>\n            You are about to register the plugin to work with the following domain.\n            Please confirm that this is a domain managed by an organisation you trust:\n        </p>\n        <div class=\"feedback\">\n            <p class=\"message error hidden\" id=\"js_main_error_feedback\"></p>\n        </div>\n        <form>\n            <div class=\"input text domain disabled\">\n                <label for=\"js_setup_domain\">Domain</label>\n                <input type=\"text\" value=\"<?= domain ?>\" id=\"js_setup_domain\" disabled=\"disabled\" />\n            </div>\n            <div class=\"input text key-fingerprint disabled\">\n                <label for=\"js_setup_key_fingerprint\">Server Key</label>\n                <input name=\"key_fingerprint\" id=\"js_setup_key_fingerprint\" value=\"\" placeholder=\"Retrieving server key. Please wait...\" type=\"text\" value=\"\" disabled=\"disabled\"/>\n                <a class=\"more\" id=\"js_server_key_info\">More</a>\n                <div class=\"message error\"></div>\n            </div>\n            <div class=\"input checkbox\">\n                <input type=\"checkbox\" id=\"js_setup_domain_check\" value=\"legit\"/>\n                <label for=\"js_setup_domain_check\">I've checked, this domain name and the server key look legitimate.</label>\n            </div>\n        </form>\n    </div>\n</div>\n<div class=\"col5 last\">\n    <!--<div class=\"video-wrapper\">-->\n        <!--<iframe width=\"400\" height=\"300\" src=\"https://www.youtube.com/embed/u-vDLf7cmf0\" frameborder=\"0\" allowfullscreen></iframe>-->\n    <!--</div>-->\n</div>\n\n"
  , __filename = "src/all/data/ejs/setup/domain_check.ejs";
try {
  var __output = "";
  function __append(s) { if (s !== undefined && s !== null) __output += s }
  with (locals || {}) {
    ; __append("<div class=\"col7\">\n    <div class=\"plugin-check-wrapper\">\n        <h3>Plugin check</h3>\n        <div class=\"plugin-check ")
    ; __line = 4
    ; __append(escapeFn( browserName ))
    ; __append(" success\">\n            <p class=\"message\">Nice one! The plugin is installed and up to date. You are good to go!</p>\n        </div>\n    </div>\n    <div class=\"why-plugin-wrapper\">\n        <h3>Url Check</h3>\n        <p>\n            You are about to register the plugin to work with the following domain.\n            Please confirm that this is a domain managed by an organisation you trust:\n        </p>\n        <div class=\"feedback\">\n            <p class=\"message error hidden\" id=\"js_main_error_feedback\"></p>\n        </div>\n        <form>\n            <div class=\"input text domain disabled\">\n                <label for=\"js_setup_domain\">Domain</label>\n                <input type=\"text\" value=\"")
    ; __line = 20
    ; __append(escapeFn( domain ))
    ; __append("\" id=\"js_setup_domain\" disabled=\"disabled\" />\n            </div>\n            <div class=\"input text key-fingerprint disabled\">\n                <label for=\"js_setup_key_fingerprint\">Server Key</label>\n                <input name=\"key_fingerprint\" id=\"js_setup_key_fingerprint\" value=\"\" placeholder=\"Retrieving server key. Please wait...\" type=\"text\" value=\"\" disabled=\"disabled\"/>\n                <a class=\"more\" id=\"js_server_key_info\">More</a>\n                <div class=\"message error\"></div>\n            </div>\n            <div class=\"input checkbox\">\n                <input type=\"checkbox\" id=\"js_setup_domain_check\" value=\"legit\"/>\n                <label for=\"js_setup_domain_check\">I've checked, this domain name and the server key look legitimate.</label>\n            </div>\n        </form>\n    </div>\n</div>\n<div class=\"col5 last\">\n    <!--<div class=\"video-wrapper\">-->\n        <!--<iframe width=\"400\" height=\"300\" src=\"https://www.youtube.com/embed/u-vDLf7cmf0\" frameborder=\"0\" allowfullscreen></iframe>-->\n    <!--</div>-->\n</div>\n\n")
    ; __line = 41
  }
  return __output;
} catch (e) {
  rethrow(e, __lines, __filename, __line, escapeFn);
}

//# sourceURL=src/all/data/ejs/setup/domain_check.ejs

}
},{}],8:[function(require,module,exports){
module.exports = function(locals, escapeFn, include, rethrow
) {
rethrow = rethrow || function rethrow(err, str, flnm, lineno, esc){
  var lines = str.split('\n');
  var start = Math.max(lineno - 3, 0);
  var end = Math.min(lines.length, lineno + 3);
  var filename = esc(flnm); // eslint-disable-line
  // Error context
  var context = lines.slice(start, end).map(function (line, i){
    var curr = i + start + 1;
    return (curr == lineno ? ' >> ' : '    ')
      + curr
      + '| '
      + line;
  }).join('\n');

  // Alter exception message
  err.path = filename;
  err.message = (filename || 'ejs') + ':'
    + lineno + '\n'
    + context + '\n\n'
    + err.message;

  throw err;
};
escapeFn = escapeFn || function (markup) {
  return markup == undefined
    ? ''
    : String(markup)
      .replace(_MATCH_HTML, encode_char);
};
var _ENCODE_HTML_RULES = {
      "&": "&amp;"
    , "<": "&lt;"
    , ">": "&gt;"
    , '"': "&#34;"
    , "'": "&#39;"
    }
  , _MATCH_HTML = /[&<>'"]/g;
function encode_char(c) {
  return _ENCODE_HTML_RULES[c] || c;
};
;
var __line = 1
  , __lines = "<!-- left collumn -->\n<div class=\"col7\">\n    <h3>An error occured</h3>\n    <div class=\"message error clearfix\">\n        <p><strong>\n            <i class=\"fa fa-times-circle\"></i> Error!</strong>\n            Something unexpected happened. The setup cannot be completed.</p>\n        <h4>What to do now ?</h4>\n        <p>Please contact us or your system administrator, and provide the debug information below.</p>\n        <p><a id=\"show-debug-info\"><i class=\"fa fa-toggle-down\"></i> See debug info</a></p>\n        <p><textarea class=\"col11 hidden\" id=\"debug-info\"><? var jsonString = JSON.stringify(setupData, null, 2); ?><?= jsonString ?></textarea></p>\n        </p>\n    </div>\n    <p>\n</div>\n\n<!-- right collumn -->\n<div class=\"col4 last\">\n\n</div>\n"
  , __filename = "src/all/data/ejs/setup/fatal_error.ejs";
try {
  var __output = "";
  function __append(s) { if (s !== undefined && s !== null) __output += s }
  with (locals || {}) {
    ; __append("<!-- left collumn -->\n<div class=\"col7\">\n    <h3>An error occured</h3>\n    <div class=\"message error clearfix\">\n        <p><strong>\n            <i class=\"fa fa-times-circle\"></i> Error!</strong>\n            Something unexpected happened. The setup cannot be completed.</p>\n        <h4>What to do now ?</h4>\n        <p>Please contact us or your system administrator, and provide the debug information below.</p>\n        <p><a id=\"show-debug-info\"><i class=\"fa fa-toggle-down\"></i> See debug info</a></p>\n        <p><textarea class=\"col11 hidden\" id=\"debug-info\">")
    ; __line = 11
    ;  var jsonString = JSON.stringify(setupData, null, 2); 
    ; __append(escapeFn( jsonString ))
    ; __append("</textarea></p>\n        </p>\n    </div>\n    <p>\n</div>\n\n<!-- right collumn -->\n<div class=\"col4 last\">\n\n</div>\n")
    ; __line = 21
  }
  return __output;
} catch (e) {
  rethrow(e, __lines, __filename, __line, escapeFn);
}

//# sourceURL=src/all/data/ejs/setup/fatal_error.ejs

}
},{}],9:[function(require,module,exports){
module.exports = function(locals, escapeFn, include, rethrow
) {
rethrow = rethrow || function rethrow(err, str, flnm, lineno, esc){
  var lines = str.split('\n');
  var start = Math.max(lineno - 3, 0);
  var end = Math.min(lines.length, lineno + 3);
  var filename = esc(flnm); // eslint-disable-line
  // Error context
  var context = lines.slice(start, end).map(function (line, i){
    var curr = i + start + 1;
    return (curr == lineno ? ' >> ' : '    ')
      + curr
      + '| '
      + line;
  }).join('\n');

  // Alter exception message
  err.path = filename;
  err.message = (filename || 'ejs') + ':'
    + lineno + '\n'
    + context + '\n\n'
    + err.message;

  throw err;
};
escapeFn = escapeFn || function (markup) {
  return markup == undefined
    ? ''
    : String(markup)
      .replace(_MATCH_HTML, encode_char);
};
var _ENCODE_HTML_RULES = {
      "&": "&amp;"
    , "<": "&lt;"
    , ">": "&gt;"
    , '"': "&#34;"
    , "'": "&#39;"
    }
  , _MATCH_HTML = /[&<>'"]/g;
function encode_char(c) {
  return _ENCODE_HTML_RULES[c] || c;
};
;
var __line = 1
  , __lines = "<!-- left collumn -->\n<div class=\"col7\">\n    <h3>Generating the secret and public key</h3>\n\n    <div class=\"progress-bar-wrapper\">\n        <span class=\"progress-bar big infinite\"><span class=\"progress \"></span></span>\n    </div>\n\n    <p>We are generating your public and secret keys. This may take a while. Just take a deep breath and enjoy being in the moment. </p>\n\n</div>\n\n<!-- right collumn -->\n<div class=\"col4 last\"></div>"
  , __filename = "src/all/data/ejs/setup/generate_key.ejs";
try {
  var __output = "";
  function __append(s) { if (s !== undefined && s !== null) __output += s }
  with (locals || {}) {
    ; __append("<!-- left collumn -->\n<div class=\"col7\">\n    <h3>Generating the secret and public key</h3>\n\n    <div class=\"progress-bar-wrapper\">\n        <span class=\"progress-bar big infinite\"><span class=\"progress \"></span></span>\n    </div>\n\n    <p>We are generating your public and secret keys. This may take a while. Just take a deep breath and enjoy being in the moment. </p>\n\n</div>\n\n<!-- right collumn -->\n<div class=\"col4 last\"></div>")
    ; __line = 14
  }
  return __output;
} catch (e) {
  rethrow(e, __lines, __filename, __line, escapeFn);
}

//# sourceURL=src/all/data/ejs/setup/generate_key.ejs

}
},{}],10:[function(require,module,exports){
module.exports = function(locals, escapeFn, include, rethrow
) {
rethrow = rethrow || function rethrow(err, str, flnm, lineno, esc){
  var lines = str.split('\n');
  var start = Math.max(lineno - 3, 0);
  var end = Math.min(lines.length, lineno + 3);
  var filename = esc(flnm); // eslint-disable-line
  // Error context
  var context = lines.slice(start, end).map(function (line, i){
    var curr = i + start + 1;
    return (curr == lineno ? ' >> ' : '    ')
      + curr
      + '| '
      + line;
  }).join('\n');

  // Alter exception message
  err.path = filename;
  err.message = (filename || 'ejs') + ':'
    + lineno + '\n'
    + context + '\n\n'
    + err.message;

  throw err;
};
escapeFn = escapeFn || function (markup) {
  return markup == undefined
    ? ''
    : String(markup)
      .replace(_MATCH_HTML, encode_char);
};
var _ENCODE_HTML_RULES = {
      "&": "&amp;"
    , "<": "&lt;"
    , ">": "&gt;"
    , '"': "&#34;"
    , "'": "&#39;"
    }
  , _MATCH_HTML = /[&<>'"]/g;
function encode_char(c) {
  return _ENCODE_HTML_RULES[c] || c;
};
;
var __line = 1
  , __lines = "<!-- left column -->\n<div class=\"col6 import-key-wrapper\">\n    <h3>Copy paste your private key below</h3>\n    <div class=\"input textarea gpgkey\">\n        <textarea name=\"data[Key][ascii]\" class=\"fluid code\" id=\"js_setup_import_key_text\"></textarea>\n    </div>\n    <div class=\"message error hidden\" id=\"KeyErrorMessage\"></div>\n    <div class=\"input file\">\n        <div class=\"input-wrapper\">\n            <div class=\"input-wrapper-2\">\n                <input name=\"data[Key][file]\" value=\"Browse...\" id=\"js_setup_import_key_browse\" type=\"submit\">\n                <span class=\"help-text\">Or select a file from your computer</span>\n            </div>\n        </div>\n    </div>\n</div>\n<div class=\"col4 last sideInfo\"></div>\n\n"
  , __filename = "src/all/data/ejs/setup/import_key.ejs";
try {
  var __output = "";
  function __append(s) { if (s !== undefined && s !== null) __output += s }
  with (locals || {}) {
    ; __append("<!-- left column -->\n<div class=\"col6 import-key-wrapper\">\n    <h3>Copy paste your private key below</h3>\n    <div class=\"input textarea gpgkey\">\n        <textarea name=\"data[Key][ascii]\" class=\"fluid code\" id=\"js_setup_import_key_text\"></textarea>\n    </div>\n    <div class=\"message error hidden\" id=\"KeyErrorMessage\"></div>\n    <div class=\"input file\">\n        <div class=\"input-wrapper\">\n            <div class=\"input-wrapper-2\">\n                <input name=\"data[Key][file]\" value=\"Browse...\" id=\"js_setup_import_key_browse\" type=\"submit\">\n                <span class=\"help-text\">Or select a file from your computer</span>\n            </div>\n        </div>\n    </div>\n</div>\n<div class=\"col4 last sideInfo\"></div>\n\n")
    ; __line = 19
  }
  return __output;
} catch (e) {
  rethrow(e, __lines, __filename, __line, escapeFn);
}

//# sourceURL=src/all/data/ejs/setup/import_key.ejs

}
},{}],11:[function(require,module,exports){
module.exports = function(locals, escapeFn, include, rethrow
) {
rethrow = rethrow || function rethrow(err, str, flnm, lineno, esc){
  var lines = str.split('\n');
  var start = Math.max(lineno - 3, 0);
  var end = Math.min(lines.length, lineno + 3);
  var filename = esc(flnm); // eslint-disable-line
  // Error context
  var context = lines.slice(start, end).map(function (line, i){
    var curr = i + start + 1;
    return (curr == lineno ? ' >> ' : '    ')
      + curr
      + '| '
      + line;
  }).join('\n');

  // Alter exception message
  err.path = filename;
  err.message = (filename || 'ejs') + ':'
    + lineno + '\n'
    + context + '\n\n'
    + err.message;

  throw err;
};
escapeFn = escapeFn || function (markup) {
  return markup == undefined
    ? ''
    : String(markup)
      .replace(_MATCH_HTML, encode_char);
};
var _ENCODE_HTML_RULES = {
      "&": "&amp;"
    , "<": "&lt;"
    , ">": "&gt;"
    , '"': "&#34;"
    , "'": "&#39;"
    }
  , _MATCH_HTML = /[&<>'"]/g;
function encode_char(c) {
  return _ENCODE_HTML_RULES[c] || c;
};
;
var __line = 1
  , __lines = "<h3>What is this private key?</h3>\n<p>\n    The key you need here is the key that was generated (or that you imported) during your first setup.\n    Remember, during the initial setup, there was a step where you were asked to make a backup.\n    You need this file now.\n</p>\n<h3>What if I don't have it?</h3>\n<p>\n    If you don't have a backup of your key, you will not be able to recover your account.\n<p>"
  , __filename = "src/all/data/ejs/setup/import_key_recover_info.ejs";
try {
  var __output = "";
  function __append(s) { if (s !== undefined && s !== null) __output += s }
  with (locals || {}) {
    ; __append("<h3>What is this private key?</h3>\n<p>\n    The key you need here is the key that was generated (or that you imported) during your first setup.\n    Remember, during the initial setup, there was a step where you were asked to make a backup.\n    You need this file now.\n</p>\n<h3>What if I don't have it?</h3>\n<p>\n    If you don't have a backup of your key, you will not be able to recover your account.\n<p>")
    ; __line = 10
  }
  return __output;
} catch (e) {
  rethrow(e, __lines, __filename, __line, escapeFn);
}

//# sourceURL=src/all/data/ejs/setup/import_key_recover_info.ejs

}
},{}],12:[function(require,module,exports){
module.exports = function(locals, escapeFn, include, rethrow
) {
rethrow = rethrow || function rethrow(err, str, flnm, lineno, esc){
  var lines = str.split('\n');
  var start = Math.max(lineno - 3, 0);
  var end = Math.min(lines.length, lineno + 3);
  var filename = esc(flnm); // eslint-disable-line
  // Error context
  var context = lines.slice(start, end).map(function (line, i){
    var curr = i + start + 1;
    return (curr == lineno ? ' >> ' : '    ')
      + curr
      + '| '
      + line;
  }).join('\n');

  // Alter exception message
  err.path = filename;
  err.message = (filename || 'ejs') + ':'
    + lineno + '\n'
    + context + '\n\n'
    + err.message;

  throw err;
};
escapeFn = escapeFn || function (markup) {
  return markup == undefined
    ? ''
    : String(markup)
      .replace(_MATCH_HTML, encode_char);
};
var _ENCODE_HTML_RULES = {
      "&": "&amp;"
    , "<": "&lt;"
    , ">": "&gt;"
    , '"': "&#34;"
    , "'": "&#39;"
    }
  , _MATCH_HTML = /[&<>'"]/g;
function encode_char(c) {
  return _ENCODE_HTML_RULES[c] || c;
};
;
var __line = 1
  , __lines = "<!-- left column -->\n<div class=\"col7\">\n    <h3>Information for public and secret key</h3>\n    <table class=\"table-info\">\n        <tr class=\"owner_name\">\n            <td>Owner Name</td>\n            <td  class=\"<?= typeof fieldsDetails['name'] != 'undefined' ? fieldsDetails['name'].status : '' ?>\">\n                <?= keyInfo.userIds[0].name ?>\n                <?= typeof fieldsDetails['name'] != 'undefined' ? ' (' + fieldsDetails['name'].original + ')' : '' ?>\n            </td>\n        </tr>\n        <tr class=\"owner_email\">\n            <td>Owner Email</td>\n            <td class=\"<?= typeof fieldsDetails['email'] != 'undefined' ? fieldsDetails['email'].status : '' ?>\">\n                <?= keyInfo.userIds[0].email ?>\n                <?= typeof fieldsDetails['email'] != 'undefined' ? ' (' + fieldsDetails['email'].original + ')' : '' ?>\n            </td>\n        </tr>\n        <tr class=\"keyid\">\n            <td>Key Id</td>\n            <td><?= keyInfo.keyId.toUpperCase() ?></td>\n        </tr>\n        <tr class=\"fingerprint\">\n            <td>Fingerprint</td>\n            <td><?= keyInfo.fingerprint.toUpperCase() ?></td>\n        </tr>\n        <tr class=\"created\">\n            <td>Created</td>\n            <td><?= keyInfo.created ?></td>\n        </tr>\n        <tr class=\"expires\">\n            <td>Expires</td>\n            <td><?= keyInfo.expires ?></td>\n        </tr>\n        <tr class=\"length\">\n            <td>Key Length</td>\n            <td><?= keyInfo.length ?></td>\n        </tr>\n        <tr class=\"algorithm\">\n            <td>Algorithm</td>\n            <td><?= keyInfo.algorithm.toUpperCase() ?></td>\n        </tr>\n    </table>\n</div>\n\n<!-- right column -->\n<div class=\"col5 last\">\n    <div class=\"message <?= status ?> side-message\">\n        <?\n        if (status == 'warning') {\n          var fieldsStr = '';\n          for (var fieldName in fieldsDetails) {\n            fieldsStr += ((fieldsStr == '') ? fieldName : ' and ' + fieldName);\n          }\n        ?>\n        <p>\n            <strong>Warning:</strong> the <?= fieldsStr ?> selected by your administrator does not match\n            the name and email of your key. Passbolt will use the information provided by the administrator to identify yourself.\n        </p>\n        <p>\n            While this is not a deal breaker this may lead to some confusion.\n        </p>\n        <p class=\"small\">\n            Note: Passbolt does not support multiple user identities at the moment.\n        </p>\n        <?\n        } else {\n        ?>\n          <p>\n              <strong>Success!</strong>\n              Nice one, it looks like a valid key with your key information matching the name and email provided by your passbolt administrator.\n              <br><br>\n              You are good to go!\n          </p>\n        <?\n        }\n        ?>\n    </div>\n</div>"
  , __filename = "src/all/data/ejs/setup/key_info.ejs";
try {
  var __output = "";
  function __append(s) { if (s !== undefined && s !== null) __output += s }
  with (locals || {}) {
    ; __append("<!-- left column -->\n<div class=\"col7\">\n    <h3>Information for public and secret key</h3>\n    <table class=\"table-info\">\n        <tr class=\"owner_name\">\n            <td>Owner Name</td>\n            <td  class=\"")
    ; __line = 7
    ; __append(escapeFn( typeof fieldsDetails['name'] != 'undefined' ? fieldsDetails['name'].status : '' ))
    ; __append("\">\n                ")
    ; __line = 8
    ; __append(escapeFn( keyInfo.userIds[0].name ))
    ; __append("\n                ")
    ; __line = 9
    ; __append(escapeFn( typeof fieldsDetails['name'] != 'undefined' ? ' (' + fieldsDetails['name'].original + ')' : '' ))
    ; __append("\n            </td>\n        </tr>\n        <tr class=\"owner_email\">\n            <td>Owner Email</td>\n            <td class=\"")
    ; __line = 14
    ; __append(escapeFn( typeof fieldsDetails['email'] != 'undefined' ? fieldsDetails['email'].status : '' ))
    ; __append("\">\n                ")
    ; __line = 15
    ; __append(escapeFn( keyInfo.userIds[0].email ))
    ; __append("\n                ")
    ; __line = 16
    ; __append(escapeFn( typeof fieldsDetails['email'] != 'undefined' ? ' (' + fieldsDetails['email'].original + ')' : '' ))
    ; __append("\n            </td>\n        </tr>\n        <tr class=\"keyid\">\n            <td>Key Id</td>\n            <td>")
    ; __line = 21
    ; __append(escapeFn( keyInfo.keyId.toUpperCase() ))
    ; __append("</td>\n        </tr>\n        <tr class=\"fingerprint\">\n            <td>Fingerprint</td>\n            <td>")
    ; __line = 25
    ; __append(escapeFn( keyInfo.fingerprint.toUpperCase() ))
    ; __append("</td>\n        </tr>\n        <tr class=\"created\">\n            <td>Created</td>\n            <td>")
    ; __line = 29
    ; __append(escapeFn( keyInfo.created ))
    ; __append("</td>\n        </tr>\n        <tr class=\"expires\">\n            <td>Expires</td>\n            <td>")
    ; __line = 33
    ; __append(escapeFn( keyInfo.expires ))
    ; __append("</td>\n        </tr>\n        <tr class=\"length\">\n            <td>Key Length</td>\n            <td>")
    ; __line = 37
    ; __append(escapeFn( keyInfo.length ))
    ; __append("</td>\n        </tr>\n        <tr class=\"algorithm\">\n            <td>Algorithm</td>\n            <td>")
    ; __line = 41
    ; __append(escapeFn( keyInfo.algorithm.toUpperCase() ))
    ; __append("</td>\n        </tr>\n    </table>\n</div>\n\n<!-- right column -->\n<div class=\"col5 last\">\n    <div class=\"message ")
    ; __line = 48
    ; __append(escapeFn( status ))
    ; __append(" side-message\">\n        ")
    ; __line = 49
    ; 
        if (status == 'warning') {
          var fieldsStr = '';
          for (var fieldName in fieldsDetails) {
            fieldsStr += ((fieldsStr == '') ? fieldName : ' and ' + fieldName);
          }
        
    ; __line = 55
    ; __append("\n        <p>\n            <strong>Warning:</strong> the ")
    ; __line = 57
    ; __append(escapeFn( fieldsStr ))
    ; __append(" selected by your administrator does not match\n            the name and email of your key. Passbolt will use the information provided by the administrator to identify yourself.\n        </p>\n        <p>\n            While this is not a deal breaker this may lead to some confusion.\n        </p>\n        <p class=\"small\">\n            Note: Passbolt does not support multiple user identities at the moment.\n        </p>\n        ")
    ; __line = 66
    ; 
        } else {
        
    ; __line = 68
    ; __append("\n          <p>\n              <strong>Success!</strong>\n              Nice one, it looks like a valid key with your key information matching the name and email provided by your passbolt administrator.\n              <br><br>\n              You are good to go!\n          </p>\n        ")
    ; __line = 75
    ; 
        }
        
    ; __line = 77
    ; __append("\n    </div>\n</div>")
    ; __line = 79
  }
  return __output;
} catch (e) {
  rethrow(e, __lines, __filename, __line, escapeFn);
}

//# sourceURL=src/all/data/ejs/setup/key_info.ejs

}
},{}],13:[function(require,module,exports){
module.exports = function(locals, escapeFn, include, rethrow
) {
rethrow = rethrow || function rethrow(err, str, flnm, lineno, esc){
  var lines = str.split('\n');
  var start = Math.max(lineno - 3, 0);
  var end = Math.min(lines.length, lineno + 3);
  var filename = esc(flnm); // eslint-disable-line
  // Error context
  var context = lines.slice(start, end).map(function (line, i){
    var curr = i + start + 1;
    return (curr == lineno ? ' >> ' : '    ')
      + curr
      + '| '
      + line;
  }).join('\n');

  // Alter exception message
  err.path = filename;
  err.message = (filename || 'ejs') + ':'
    + lineno + '\n'
    + context + '\n\n'
    + err.message;

  throw err;
};
escapeFn = escapeFn || function (markup) {
  return markup == undefined
    ? ''
    : String(markup)
      .replace(_MATCH_HTML, encode_char);
};
var _ENCODE_HTML_RULES = {
      "&": "&amp;"
    , "<": "&lt;"
    , ">": "&gt;"
    , '"': "&#34;"
    , "'": "&#39;"
    }
  , _MATCH_HTML = /[&<>'"]/g;
function encode_char(c) {
  return _ENCODE_HTML_RULES[c] || c;
};
;
var __line = 1
  , __lines = "<!-- left collumn -->\n<div class=\"col7\">\n    <h3>Setup is complete</h3>\n    <div class=\"message success\">\n        <strong>\n            <i class=\"fa fa-check-circle\"></i>\n            Success!\n        </strong>\n        You have successfully completed the setup, thank you!\n        You will soon be redirected to the login page.\n    </div>\n    <div class=\"input-wrapper\">\n        <a id=\"js_spinner\" class=\"button primary next big processing\">login!</a>\n        <a>Click here if you can't wait</a>.\n    </div>\n    <p>\n    </p>\n</div>\n\n<!-- right collumn -->\n<div class=\"col4 last\">\n\n</div>\n"
  , __filename = "src/all/data/ejs/setup/login_redirection.ejs";
try {
  var __output = "";
  function __append(s) { if (s !== undefined && s !== null) __output += s }
  with (locals || {}) {
    ; __append("<!-- left collumn -->\n<div class=\"col7\">\n    <h3>Setup is complete</h3>\n    <div class=\"message success\">\n        <strong>\n            <i class=\"fa fa-check-circle\"></i>\n            Success!\n        </strong>\n        You have successfully completed the setup, thank you!\n        You will soon be redirected to the login page.\n    </div>\n    <div class=\"input-wrapper\">\n        <a id=\"js_spinner\" class=\"button primary next big processing\">login!</a>\n        <a>Click here if you can't wait</a>.\n    </div>\n    <p>\n    </p>\n</div>\n\n<!-- right collumn -->\n<div class=\"col4 last\">\n\n</div>\n")
    ; __line = 24
  }
  return __output;
} catch (e) {
  rethrow(e, __lines, __filename, __line, escapeFn);
}

//# sourceURL=src/all/data/ejs/setup/login_redirection.ejs

}
},{}],14:[function(require,module,exports){
module.exports = function(locals, escapeFn, include, rethrow
) {
rethrow = rethrow || function rethrow(err, str, flnm, lineno, esc){
  var lines = str.split('\n');
  var start = Math.max(lineno - 3, 0);
  var end = Math.min(lines.length, lineno + 3);
  var filename = esc(flnm); // eslint-disable-line
  // Error context
  var context = lines.slice(start, end).map(function (line, i){
    var curr = i + start + 1;
    return (curr == lineno ? ' >> ' : '    ')
      + curr
      + '| '
      + line;
  }).join('\n');

  // Alter exception message
  err.path = filename;
  err.message = (filename || 'ejs') + ':'
    + lineno + '\n'
    + context + '\n\n'
    + err.message;

  throw err;
};
escapeFn = escapeFn || function (markup) {
  return markup == undefined
    ? ''
    : String(markup)
      .replace(_MATCH_HTML, encode_char);
};
var _ENCODE_HTML_RULES = {
      "&": "&amp;"
    , "<": "&lt;"
    , ">": "&gt;"
    , '"': "&#34;"
    , "'": "&#39;"
    }
  , _MATCH_HTML = /[&<>'"]/g;
function encode_char(c) {
  return _ENCODE_HTML_RULES[c] || c;
};
;
var __line = 1
  , __lines = "<ul>\n<? for (var i in menuSteps) { ?>\n    <?\n      var menuClass = 'disabled';\n      switch (menuSteps[i].state) {\n        case 'past':\n          menuClass = 'past';\n          break;\n        case 'current':\n          menuClass = 'selected';\n          break;\n      }\n    ?>\n    <li class=\"<?= menuClass ?>\">\n        <? if (menuClass == \"selected\" || menuClass == \"past\") { ?>\n        <a><?= steps[menuSteps[i].stepId].label ?></a>\n        <? } else { ?>\n        <?= steps[menuSteps[i].stepId].label ?>\n        <? } ?>\n    </li>\n<? } ?>\n</ul>\n"
  , __filename = "src/all/data/ejs/setup/menu.ejs";
try {
  var __output = "";
  function __append(s) { if (s !== undefined && s !== null) __output += s }
  with (locals || {}) {
    ; __append("<ul>\n")
    ; __line = 2
    ;  for (var i in menuSteps) { 
    ; __append("\n    ")
    ; __line = 3
    ; 
      var menuClass = 'disabled';
      switch (menuSteps[i].state) {
        case 'past':
          menuClass = 'past';
          break;
        case 'current':
          menuClass = 'selected';
          break;
      }
    
    ; __line = 13
    ; __append("\n    <li class=\"")
    ; __line = 14
    ; __append(escapeFn( menuClass ))
    ; __append("\">\n        ")
    ; __line = 15
    ;  if (menuClass == "selected" || menuClass == "past") { 
    ; __append("\n        <a>")
    ; __line = 16
    ; __append(escapeFn( steps[menuSteps[i].stepId].label ))
    ; __append("</a>\n        ")
    ; __line = 17
    ;  } else { 
    ; __append("\n        ")
    ; __line = 18
    ; __append(escapeFn( steps[menuSteps[i].stepId].label ))
    ; __append("\n        ")
    ; __line = 19
    ;  } 
    ; __append("\n    </li>\n")
    ; __line = 21
    ;  } 
    ; __append("\n</ul>\n")
    ; __line = 23
  }
  return __output;
} catch (e) {
  rethrow(e, __lines, __filename, __line, escapeFn);
}

//# sourceURL=src/all/data/ejs/setup/menu.ejs

}
},{}],15:[function(require,module,exports){
module.exports = function(locals, escapeFn, include, rethrow
) {
rethrow = rethrow || function rethrow(err, str, flnm, lineno, esc){
  var lines = str.split('\n');
  var start = Math.max(lineno - 3, 0);
  var end = Math.min(lines.length, lineno + 3);
  var filename = esc(flnm); // eslint-disable-line
  // Error context
  var context = lines.slice(start, end).map(function (line, i){
    var curr = i + start + 1;
    return (curr == lineno ? ' >> ' : '    ')
      + curr
      + '| '
      + line;
  }).join('\n');

  // Alter exception message
  err.path = filename;
  err.message = (filename || 'ejs') + ':'
    + lineno + '\n'
    + context + '\n\n'
    + err.message;

  throw err;
};
escapeFn = escapeFn || function (markup) {
  return markup == undefined
    ? ''
    : String(markup)
      .replace(_MATCH_HTML, encode_char);
};
var _ENCODE_HTML_RULES = {
      "&": "&amp;"
    , "<": "&lt;"
    , ">": "&gt;"
    , '"': "&#34;"
    , "'": "&#39;"
    }
  , _MATCH_HTML = /[&<>'"]/g;
function encode_char(c) {
  return _ENCODE_HTML_RULES[c] || c;
};
;
var __line = 1
  , __lines = "<!-- left collumn -->\n<div class=\"col7\">\n    <h3>Set your passphrase</h3>\n    <p>This is the only passphrase you will need to remember from now on, so make sure you choose it wisely! </p>\n\n    <div class=\"input-password-wrapper\">\n        <div class=\"input password required\">\n            <label for=\"js_field_password\" class=\"hidden\">New passphrase</label>\n            <input name=\"passbolt.model.User.password\" type=\"password\" id=\"js_field_password\" placeholder=\"enter your passphrase here\">\n            <input class=\"required hidden\" type=\"text\" id=\"js_field_password_clear\">\n        </div>\n        <ul class=\"actions inline\">\n            <li>\n                <a id=\"js_show_pwd_button\" class=\"button toggle mad_controller_component_button_controller mad_view_view js_component ready\n                    tooltip-right always-show large\" data-tooltip=\"click here to view in clear text\">\n                    <i class=\"fa fa-eye fa-lg\"></i>\n                    <span class=\"visuallyhidden\">view</span>\n                </a>\n            </li>\n        </ul>\n        <div id=\"js_user_pwd_strength\" class=\"password-complexity\">\n        </div>\n    </div>\n\n    <div class=\"password-hints\">\n        <p>Some tips for choosing a strong passphrase:</p>\n        <ul id=\"js_password_match_criterias\">\n        </ul>\n    </div>\n</div>\n\n<!-- right collumn -->\n<div class=\"col4 last\">\n\n</div>"
  , __filename = "src/all/data/ejs/setup/secret.ejs";
try {
  var __output = "";
  function __append(s) { if (s !== undefined && s !== null) __output += s }
  with (locals || {}) {
    ; __append("<!-- left collumn -->\n<div class=\"col7\">\n    <h3>Set your passphrase</h3>\n    <p>This is the only passphrase you will need to remember from now on, so make sure you choose it wisely! </p>\n\n    <div class=\"input-password-wrapper\">\n        <div class=\"input password required\">\n            <label for=\"js_field_password\" class=\"hidden\">New passphrase</label>\n            <input name=\"passbolt.model.User.password\" type=\"password\" id=\"js_field_password\" placeholder=\"enter your passphrase here\">\n            <input class=\"required hidden\" type=\"text\" id=\"js_field_password_clear\">\n        </div>\n        <ul class=\"actions inline\">\n            <li>\n                <a id=\"js_show_pwd_button\" class=\"button toggle mad_controller_component_button_controller mad_view_view js_component ready\n                    tooltip-right always-show large\" data-tooltip=\"click here to view in clear text\">\n                    <i class=\"fa fa-eye fa-lg\"></i>\n                    <span class=\"visuallyhidden\">view</span>\n                </a>\n            </li>\n        </ul>\n        <div id=\"js_user_pwd_strength\" class=\"password-complexity\">\n        </div>\n    </div>\n\n    <div class=\"password-hints\">\n        <p>Some tips for choosing a strong passphrase:</p>\n        <ul id=\"js_password_match_criterias\">\n        </ul>\n    </div>\n</div>\n\n<!-- right collumn -->\n<div class=\"col4 last\">\n\n</div>")
    ; __line = 35
  }
  return __output;
} catch (e) {
  rethrow(e, __lines, __filename, __line, escapeFn);
}

//# sourceURL=src/all/data/ejs/setup/secret.ejs

}
},{}],16:[function(require,module,exports){
module.exports = function(locals, escapeFn, include, rethrow
) {
rethrow = rethrow || function rethrow(err, str, flnm, lineno, esc){
  var lines = str.split('\n');
  var start = Math.max(lineno - 3, 0);
  var end = Math.min(lines.length, lineno + 3);
  var filename = esc(flnm); // eslint-disable-line
  // Error context
  var context = lines.slice(start, end).map(function (line, i){
    var curr = i + start + 1;
    return (curr == lineno ? ' >> ' : '    ')
      + curr
      + '| '
      + line;
  }).join('\n');

  // Alter exception message
  err.path = filename;
  err.message = (filename || 'ejs') + ':'
    + lineno + '\n'
    + context + '\n\n'
    + err.message;

  throw err;
};
escapeFn = escapeFn || function (markup) {
  return markup == undefined
    ? ''
    : String(markup)
      .replace(_MATCH_HTML, encode_char);
};
var _ENCODE_HTML_RULES = {
      "&": "&amp;"
    , "<": "&lt;"
    , ">": "&gt;"
    , '"': "&#34;"
    , "'": "&#39;"
    }
  , _MATCH_HTML = /[&<>'"]/g;
function encode_char(c) {
  return _ENCODE_HTML_RULES[c] || c;
};
;
var __line = 1
  , __lines = "<!-- left collumn -->\n<div class=\"col7\">\n    <h3>Set a security token</h3>\n    <p>Please choose a color and three letters (or remember the combination we conveniently generated for you).</p>\n\n    <div class=\"colorpicker\">\n        <div class=\"input color\">\n            <input type=\"text\" id=\"js_security_token_text\" class=\"token\" name=\"text\"  maxlength=\"3\"/>\n            <div id=\"js_field_name_feedback\" class=\"message error hidden\"><!-- Error message --></div>\n            <input type=\"hidden\" id=\"js_security_token_background\" name=\"background\"  />\n            <input type=\"hidden\" id=\"js_security_token_color\" name=\"color\" />\n        </div>\n        <div id=\"js_colorpicker\"></div>\n    </div>\n\n</div>\n\n<!-- right collumn -->\n<div class=\"col4 last\">\n    <h3>Wait, why do I need this?</h3>\n    <p>\n        This token is used to prevent malicious web pages tricking you by mimicking passbolt dialogs in\n        order to steal your data (aka. this protects you from phishing attacks).\n    </p>\n    <p>\n        This visual cue will be shown whenever we ask you for your passphrase and other sensitive places to\n        help make sure you are dealing with an authentic passbolt dialog and not a fake one!\n    </p>\n</div>\n"
  , __filename = "src/all/data/ejs/setup/security_token.ejs";
try {
  var __output = "";
  function __append(s) { if (s !== undefined && s !== null) __output += s }
  with (locals || {}) {
    ; __append("<!-- left collumn -->\n<div class=\"col7\">\n    <h3>Set a security token</h3>\n    <p>Please choose a color and three letters (or remember the combination we conveniently generated for you).</p>\n\n    <div class=\"colorpicker\">\n        <div class=\"input color\">\n            <input type=\"text\" id=\"js_security_token_text\" class=\"token\" name=\"text\"  maxlength=\"3\"/>\n            <div id=\"js_field_name_feedback\" class=\"message error hidden\"><!-- Error message --></div>\n            <input type=\"hidden\" id=\"js_security_token_background\" name=\"background\"  />\n            <input type=\"hidden\" id=\"js_security_token_color\" name=\"color\" />\n        </div>\n        <div id=\"js_colorpicker\"></div>\n    </div>\n\n</div>\n\n<!-- right collumn -->\n<div class=\"col4 last\">\n    <h3>Wait, why do I need this?</h3>\n    <p>\n        This token is used to prevent malicious web pages tricking you by mimicking passbolt dialogs in\n        order to steal your data (aka. this protects you from phishing attacks).\n    </p>\n    <p>\n        This visual cue will be shown whenever we ask you for your passphrase and other sensitive places to\n        help make sure you are dealing with an authentic passbolt dialog and not a fake one!\n    </p>\n</div>\n")
    ; __line = 30
  }
  return __output;
} catch (e) {
  rethrow(e, __lines, __filename, __line, escapeFn);
}

//# sourceURL=src/all/data/ejs/setup/security_token.ejs

}
},{}]},{},[1]);
//result must be structured-clonable data
undefined;
