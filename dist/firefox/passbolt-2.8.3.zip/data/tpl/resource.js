(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
window.templates = window.templates || {};
window.templates.resource = window.templates.resource || {};
window.templates.resource.shareAroPermissionsItem = require('./resource/shareAroPermissionsItem.js');
window.templates.resource.shareAutocomplete = require('./resource/shareAutocomplete.js');
window.templates.resource.shareBulkTitleTooltip = require('./resource/shareBulkTitleTooltip.js');
window.templates.resource.shareDialog = require('./resource/shareDialog.js');
window.templates.resource.shareFormAdd = require('./resource/shareFormAdd.js');

},{"./resource/shareAroPermissionsItem.js":2,"./resource/shareAutocomplete.js":3,"./resource/shareBulkTitleTooltip.js":4,"./resource/shareDialog.js":5,"./resource/shareFormAdd.js":6}],2:[function(require,module,exports){
module.exports = function(locals, escapeFn, include, rethrow
/*``*/) {
rethrow = rethrow || function rethrow(err, str, flnm, lineno, esc){
  var lines = str.split('\n');
  var start = Math.max(lineno - 3, 0);
  var end = Math.min(lines.length, lineno + 3);
  var filename = esc(flnm); // eslint-disable-line
  // Error context
  var context = lines.slice(start, end).map(function (line, i){
    var curr = i + start + 1;
    return (curr == lineno ? ' >> ' : '    ')
      + curr
      + '| '
      + line;
  }).join('\n');

  // Alter exception message
  err.path = filename;
  err.message = (filename || 'ejs') + ':'
    + lineno + '\n'
    + context + '\n\n'
    + err.message;

  throw err;
};
escapeFn = escapeFn || function (markup) {
  return markup == undefined
    ? ''
    : String(markup)
      .replace(_MATCH_HTML, encode_char);
};
var _ENCODE_HTML_RULES = {
      "&": "&amp;"
    , "<": "&lt;"
    , ">": "&gt;"
    , '"': "&#34;"
    , "'": "&#39;"
    }
  , _MATCH_HTML = /[&<>'"]/g;
function encode_char(c) {
  return _ENCODE_HTML_RULES[c] || c;
};
;
var __line = 1
  , __lines = "<?\nlet avatarPath = '';\nlet aroName = '';\nlet aroDetails = '';\n\nif (aroPermissions.aro.profile) {\n    avatarPath = `${domain}/${aroPermissions.aro.profile.avatar.url.small}`;\n    aroName = `${aroPermissions.aro.profile.first_name} ${aroPermissions.aro.profile.last_name}`;\n    aroDetails = aroPermissions.aro.username;\n} else {\n    avatarPath = `${domain}/img/avatar/group_default.png`;\n    aroName = aroPermissions.aro.name;\n    aroDetails = 'Group';\n}\n?>\n<li id=\"<?= aroPermissions.aro.id ?>\" class=\"row\">\n    <div class=\"avatar\">\n        <img src=\"<?= avatarPath ?>\"/>\n    </div>\n\n    <div class=\"group\">\n        <span class=\"name\"><?= aroName ?></span>\n        <span class=\"details\"><a><?= aroDetails ?></a></span>\n    </div>\n\n    <div class=\"select rights\">\n        <select class=\"permission <?= !canEdit ? 'disabled' : '' ?>\" <?= !canEdit ? 'disabled=\"disabled\"' : '' ?>>\n            <option value=\"1\" <?= aroPermissions.type == 1 ? 'selected=\"selected\"' : ''?>>can read</option>\n            <option value=\"7\" <?= aroPermissions.type == 7 ? 'selected=\"selected\"' : ''?>>can update</option>\n            <option value=\"15\" <?= aroPermissions.type == 15 ? 'selected=\"selected\"' : ''?>>is owner</option>\n            <? if (aroPermissions.type == -1) { ?>\n            <option value=\"-1\" selected=\"selected\">varies</option>\n            <? } ?>\n        </select>\n<? if (aroPermissions.type == -1) { ?>\n        <div href=\"#\" class=\"more_details tooltip-alt\">\n            <i class=\"fa fa-info-circle\"></i>\n            <div class=\"tooltip-text right\">\n                <? if(aroPermissions.variesDetails[0].length) { ?>\n                <b>no access</b>: <?= aroPermissions.variesDetails[0].join(', ') ?><br/>\n                <? } ?>\n                <? if(aroPermissions.variesDetails[1].length) { ?>\n                <b>can read</b>: <?= aroPermissions.variesDetails[1].join(', ') ?><br/>\n                <? } ?>\n                <? if(aroPermissions.variesDetails[7].length) { ?>\n                <b>can update</b>: <?= aroPermissions.variesDetails[7].join(', ') ?><br/>\n                <? } ?>\n                <? if(aroPermissions.variesDetails[15].length) { ?>\n                <b>is owner</b>: <?= aroPermissions.variesDetails[15].join(', ') ?><br/>\n                <? } ?>\n            </div>\n        </div>\n<? } ?>\n    </div>\n\n    <div id=\"js_actions_rs_perm_<?= aroPermissions.aro.id ?>\" class=\"actions\">\n        <a class=\"js-share-delete-button close <?= !canEdit ? 'disabled' : '' ?>\" title=\"remove\">\n            <i class=\"fa fa-times-circle\"></i>\n            <span class=\"visuallyhidden\">remove</span>\n        </a>\n    </div>\n</li>\n"
  , __filename = "src/all/data/ejs/resource/shareAroPermissionsItem.ejs";
try {
  var __output = [], __append = __output.push.bind(__output);
  with (locals || {}) {
    ; 
let avatarPath = '';
let aroName = '';
let aroDetails = '';

if (aroPermissions.aro.profile) {
    avatarPath = `${domain}/${aroPermissions.aro.profile.avatar.url.small}`;
    aroName = `${aroPermissions.aro.profile.first_name} ${aroPermissions.aro.profile.last_name}`;
    aroDetails = aroPermissions.aro.username;
} else {
    avatarPath = `${domain}/img/avatar/group_default.png`;
    aroName = aroPermissions.aro.name;
    aroDetails = 'Group';
}

    ; __line = 15
    ; __append("\n<li id=\"")
    ; __line = 16
    ; __append(escapeFn( aroPermissions.aro.id ))
    ; __append("\" class=\"row\">\n    <div class=\"avatar\">\n        <img src=\"")
    ; __line = 18
    ; __append(escapeFn( avatarPath ))
    ; __append("\"/>\n    </div>\n\n    <div class=\"group\">\n        <span class=\"name\">")
    ; __line = 22
    ; __append(escapeFn( aroName ))
    ; __append("</span>\n        <span class=\"details\"><a>")
    ; __line = 23
    ; __append(escapeFn( aroDetails ))
    ; __append("</a></span>\n    </div>\n\n    <div class=\"select rights\">\n        <select class=\"permission ")
    ; __line = 27
    ; __append(escapeFn( !canEdit ? 'disabled' : '' ))
    ; __append("\" ")
    ; __append(escapeFn( !canEdit ? 'disabled="disabled"' : '' ))
    ; __append(">\n            <option value=\"1\" ")
    ; __line = 28
    ; __append(escapeFn( aroPermissions.type == 1 ? 'selected="selected"' : ''))
    ; __append(">can read</option>\n            <option value=\"7\" ")
    ; __line = 29
    ; __append(escapeFn( aroPermissions.type == 7 ? 'selected="selected"' : ''))
    ; __append(">can update</option>\n            <option value=\"15\" ")
    ; __line = 30
    ; __append(escapeFn( aroPermissions.type == 15 ? 'selected="selected"' : ''))
    ; __append(">is owner</option>\n            ")
    ; __line = 31
    ;  if (aroPermissions.type == -1) { 
    ; __append("\n            <option value=\"-1\" selected=\"selected\">varies</option>\n            ")
    ; __line = 33
    ;  } 
    ; __append("\n        </select>\n")
    ; __line = 35
    ;  if (aroPermissions.type == -1) { 
    ; __append("\n        <div href=\"#\" class=\"more_details tooltip-alt\">\n            <i class=\"fa fa-info-circle\"></i>\n            <div class=\"tooltip-text right\">\n                ")
    ; __line = 39
    ;  if(aroPermissions.variesDetails[0].length) { 
    ; __append("\n                <b>no access</b>: ")
    ; __line = 40
    ; __append(escapeFn( aroPermissions.variesDetails[0].join(', ') ))
    ; __append("<br/>\n                ")
    ; __line = 41
    ;  } 
    ; __append("\n                ")
    ; __line = 42
    ;  if(aroPermissions.variesDetails[1].length) { 
    ; __append("\n                <b>can read</b>: ")
    ; __line = 43
    ; __append(escapeFn( aroPermissions.variesDetails[1].join(', ') ))
    ; __append("<br/>\n                ")
    ; __line = 44
    ;  } 
    ; __append("\n                ")
    ; __line = 45
    ;  if(aroPermissions.variesDetails[7].length) { 
    ; __append("\n                <b>can update</b>: ")
    ; __line = 46
    ; __append(escapeFn( aroPermissions.variesDetails[7].join(', ') ))
    ; __append("<br/>\n                ")
    ; __line = 47
    ;  } 
    ; __append("\n                ")
    ; __line = 48
    ;  if(aroPermissions.variesDetails[15].length) { 
    ; __append("\n                <b>is owner</b>: ")
    ; __line = 49
    ; __append(escapeFn( aroPermissions.variesDetails[15].join(', ') ))
    ; __append("<br/>\n                ")
    ; __line = 50
    ;  } 
    ; __append("\n            </div>\n        </div>\n")
    ; __line = 53
    ;  } 
    ; __append("\n    </div>\n\n    <div id=\"js_actions_rs_perm_")
    ; __line = 56
    ; __append(escapeFn( aroPermissions.aro.id ))
    ; __append("\" class=\"actions\">\n        <a class=\"js-share-delete-button close ")
    ; __line = 57
    ; __append(escapeFn( !canEdit ? 'disabled' : '' ))
    ; __append("\" title=\"remove\">\n            <i class=\"fa fa-times-circle\"></i>\n            <span class=\"visuallyhidden\">remove</span>\n        </a>\n    </div>\n</li>\n")
    ; __line = 63
  }
  return __output.join("");
} catch (e) {
  rethrow(e, __lines, __filename, __line, escapeFn);
}

}
},{}],3:[function(require,module,exports){
module.exports = function(locals, escapeFn, include, rethrow
/*``*/) {
rethrow = rethrow || function rethrow(err, str, flnm, lineno, esc){
  var lines = str.split('\n');
  var start = Math.max(lineno - 3, 0);
  var end = Math.min(lines.length, lineno + 3);
  var filename = esc(flnm); // eslint-disable-line
  // Error context
  var context = lines.slice(start, end).map(function (line, i){
    var curr = i + start + 1;
    return (curr == lineno ? ' >> ' : '    ')
      + curr
      + '| '
      + line;
  }).join('\n');

  // Alter exception message
  err.path = filename;
  err.message = (filename || 'ejs') + ':'
    + lineno + '\n'
    + context + '\n\n'
    + err.message;

  throw err;
};
escapeFn = escapeFn || function (markup) {
  return markup == undefined
    ? ''
    : String(markup)
      .replace(_MATCH_HTML, encode_char);
};
var _ENCODE_HTML_RULES = {
      "&": "&amp;"
    , "<": "&lt;"
    , ">": "&gt;"
    , '"': "&#34;"
    , "'": "&#39;"
    }
  , _MATCH_HTML = /[&<>'"]/g;
function encode_char(c) {
  return _ENCODE_HTML_RULES[c] || c;
};
;
var __line = 1
  , __lines = "<ul>\n<? if (!aros.length) { ?>\n    <li>\n        <div class=\"row\">\n            <div class=\"main-cell-wrapper\">\n                <div class=\"main-cell\" style=\"font-size:16px;\">\n                    No user or group found\n                </div>\n            </div>\n        </div>\n    </li>\n<? } ?>\n<? for(let i in aros) {\n    const aro = aros[i];\n    let aroAvatarPath, aroName, aroDetails, cssClass;\n    if (aro.profile) {\n        aroAvatarPath = `${domain}/${aro.profile.avatar.url.small}`;\n        aroName = `${aro.profile.first_name} ${aro.profile.last_name} (${aro.gpgkey.key_id})`;\n        aroDetails = aro.username;\n        cssClass = 'user';\n    } else {\n        aroAvatarPath = `${domain}/img/avatar/group_default.png`;\n        aroName = aro.name;\n        aroDetails = `${aro.user_count} Member(s)`;\n        cssClass = 'group';\n    }\n?>\n    <li id=\"<?= aro.id ?>\">\n        <div class=\"row\">\n            <div class=\"main-cell-wrapper\">\n                <div class=\"main-cell\">\n                    <a>\n                        <div class=\"avatar\">\n                            <img src=\"<?= aroAvatarPath ?>\"/>\n                        </div>\n                        <div class=\"<?= cssClass ?>\">\n                            <span class=\"name\"><?= aroName ?></span>\n                            <span class=\"details\" title=\"<?= aroDetails ?>\"><?= aroDetails ?></span>\n                        </div>\n                    </a>\n                </div>\n            </div>\n        </div>\n    </li>\n<? } ?>\n</ul>\n"
  , __filename = "src/all/data/ejs/resource/shareAutocomplete.ejs";
try {
  var __output = [], __append = __output.push.bind(__output);
  with (locals || {}) {
    ; __append("<ul>\n")
    ; __line = 2
    ;  if (!aros.length) { 
    ; __append("\n    <li>\n        <div class=\"row\">\n            <div class=\"main-cell-wrapper\">\n                <div class=\"main-cell\" style=\"font-size:16px;\">\n                    No user or group found\n                </div>\n            </div>\n        </div>\n    </li>\n")
    ; __line = 12
    ;  } 
    ; __append("\n")
    ; __line = 13
    ;  for(let i in aros) {
    const aro = aros[i];
    let aroAvatarPath, aroName, aroDetails, cssClass;
    if (aro.profile) {
        aroAvatarPath = `${domain}/${aro.profile.avatar.url.small}`;
        aroName = `${aro.profile.first_name} ${aro.profile.last_name} (${aro.gpgkey.key_id})`;
        aroDetails = aro.username;
        cssClass = 'user';
    } else {
        aroAvatarPath = `${domain}/img/avatar/group_default.png`;
        aroName = aro.name;
        aroDetails = `${aro.user_count} Member(s)`;
        cssClass = 'group';
    }

    ; __line = 27
    ; __append("\n    <li id=\"")
    ; __line = 28
    ; __append(escapeFn( aro.id ))
    ; __append("\">\n        <div class=\"row\">\n            <div class=\"main-cell-wrapper\">\n                <div class=\"main-cell\">\n                    <a>\n                        <div class=\"avatar\">\n                            <img src=\"")
    ; __line = 34
    ; __append(escapeFn( aroAvatarPath ))
    ; __append("\"/>\n                        </div>\n                        <div class=\"")
    ; __line = 36
    ; __append(escapeFn( cssClass ))
    ; __append("\">\n                            <span class=\"name\">")
    ; __line = 37
    ; __append(escapeFn( aroName ))
    ; __append("</span>\n                            <span class=\"details\" title=\"")
    ; __line = 38
    ; __append(escapeFn( aroDetails ))
    ; __append("\">")
    ; __append(escapeFn( aroDetails ))
    ; __append("</span>\n                        </div>\n                    </a>\n                </div>\n            </div>\n        </div>\n    </li>\n")
    ; __line = 45
    ;  } 
    ; __append("\n</ul>\n")
    ; __line = 47
  }
  return __output.join("");
} catch (e) {
  rethrow(e, __lines, __filename, __line, escapeFn);
}

}
},{}],4:[function(require,module,exports){
module.exports = function(locals, escapeFn, include, rethrow
/*``*/) {
rethrow = rethrow || function rethrow(err, str, flnm, lineno, esc){
  var lines = str.split('\n');
  var start = Math.max(lineno - 3, 0);
  var end = Math.min(lines.length, lineno + 3);
  var filename = esc(flnm); // eslint-disable-line
  // Error context
  var context = lines.slice(start, end).map(function (line, i){
    var curr = i + start + 1;
    return (curr == lineno ? ' >> ' : '    ')
      + curr
      + '| '
      + line;
  }).join('\n');

  // Alter exception message
  err.path = filename;
  err.message = (filename || 'ejs') + ':'
    + lineno + '\n'
    + context + '\n\n'
    + err.message;

  throw err;
};
escapeFn = escapeFn || function (markup) {
  return markup == undefined
    ? ''
    : String(markup)
      .replace(_MATCH_HTML, encode_char);
};
var _ENCODE_HTML_RULES = {
      "&": "&amp;"
    , "<": "&lt;"
    , ">": "&gt;"
    , '"': "&#34;"
    , "'": "&#39;"
    }
  , _MATCH_HTML = /[&<>'"]/g;
function encode_char(c) {
  return _ENCODE_HTML_RULES[c] || c;
};
;
var __line = 1
  , __lines = "<div class=\"more_details tooltip-alt\">\n    <i class=\"fa fa-info-circle\"></i>\n    <div class=\"tooltip-text right\">\n        <?= resources.map(resource => resource.name).join(', '); ?>\n    </div>\n</div>\n"
  , __filename = "src/all/data/ejs/resource/shareBulkTitleTooltip.ejs";
try {
  var __output = [], __append = __output.push.bind(__output);
  with (locals || {}) {
    ; __append("<div class=\"more_details tooltip-alt\">\n    <i class=\"fa fa-info-circle\"></i>\n    <div class=\"tooltip-text right\">\n        ")
    ; __line = 4
    ; __append(escapeFn( resources.map(resource => resource.name).join(', ') ))
    ; __append("\n    </div>\n</div>\n")
    ; __line = 7
  }
  return __output.join("");
} catch (e) {
  rethrow(e, __lines, __filename, __line, escapeFn);
}

}
},{}],5:[function(require,module,exports){
module.exports = function(locals, escapeFn, include, rethrow
/*``*/) {
rethrow = rethrow || function rethrow(err, str, flnm, lineno, esc){
  var lines = str.split('\n');
  var start = Math.max(lineno - 3, 0);
  var end = Math.min(lines.length, lineno + 3);
  var filename = esc(flnm); // eslint-disable-line
  // Error context
  var context = lines.slice(start, end).map(function (line, i){
    var curr = i + start + 1;
    return (curr == lineno ? ' >> ' : '    ')
      + curr
      + '| '
      + line;
  }).join('\n');

  // Alter exception message
  err.path = filename;
  err.message = (filename || 'ejs') + ':'
    + lineno + '\n'
    + context + '\n\n'
    + err.message;

  throw err;
};
escapeFn = escapeFn || function (markup) {
  return markup == undefined
    ? ''
    : String(markup)
      .replace(_MATCH_HTML, encode_char);
};
var _ENCODE_HTML_RULES = {
      "&": "&amp;"
    , "<": "&lt;"
    , ">": "&gt;"
    , '"': "&#34;"
    , "'": "&#39;"
    }
  , _MATCH_HTML = /[&<>'"]/g;
function encode_char(c) {
  return _ENCODE_HTML_RULES[c] || c;
};
;
var __line = 1
  , __lines = "<div class=\"dialog-wrapper\">\n    <div class=\"dialog share-password-dialog\">\n        <div class=\"dialog-header\">\n<? if (resourcesCount > 1) { ?>\n            <h2><span>Share <?= resourcesCount ?> passwords </span></h2>\n<? } else { ?>\n            <h2>Share<span class=\"dialog-header-subtitle\"></span></h2>\n<? } ?>\n            <a class=\"dialog-close js-dialog-close\">\n                <i class=\"fa fa-close\"></i>\n                <span class=\"visuallyhidden\">close</span>\n            </a>\n        </div>\n        <div class=\"js-dialog-content dialog-content\">\n\n<? if (resourcesCount == 1) { ?>\n            <ul class=\"tabs-nav menu\">\n                <li id=\"js-share-go-to-edit\">\n                    <div class=\"row\">\n                        <div class=\"main-cell-wrapper\">\n                            <div class=\"main-cell\">\n                                <a><span>Edit</span></a>\n                            </div>\n                        </div>\n                    </div>\n                </li>\n                <li id=\"js-share-go-to-share\" class=\"\">\n                    <div class=\"row\">\n                        <div class=\"main-cell-wrapper\">\n                            <div class=\"main-cell\">\n                                <a class=\"selected\"><span>Share</span></a>\n                            </div>\n                        </div>\n                    </div>\n                </li>\n            </ul>\n\n            <div class=\"tab\">\n                <div class=\"tab-content\" style=\"display:block\">\n<? } ?>\n\n                    <div class=\"processing-wrapper\">\n                        <span class=\"processing-text\">Retrieving permissions</span>\n                    </div>\n\n                    <div id=\"js-share-edit-list\" class=\"form-content permission-edit\">\n                        <ul class=\"permissions scroll\"></ul>\n                    </div>\n\n                    <div id=\"js-share-feedbacks\" class=\"feedbacks message hidden\"></div>\n\n                    <div id=\"js-share-form-content-add\" class=\"form-content permission-add hidden\">\n                        <div class=\"input text autocomplete\">\n                            <label for=\"js-search-aros-input\">Share with people or groups</label>\n                            <input maxlength=\"255\" id=\"js-search-aros-input\" placeholder=\"enter one name or email\" autocomplete=\"off\" type=\"text\">\n                            <div class=\"security-token\"></div>\n                        </div>\n                        <div id=\"js-search-aro-autocomplete\" class=\"autocomplete-wrapper hidden\">\n                            <div class=\"autocomplete-content scroll\"></div>\n                        </div>\n                    </div>\n\n                    <div class=\"submit-wrapper clearfix\">\n                        <input id=\"js-share-save\" type=\"submit\" class=\"button disabled primary\" value=\"save\" disabled=\"disabled\"/>\n                        <a id=\"js-share-cancel\" class=\"cancel\">cancel</a>\n                    </div>\n                </div>\n\n<? if (resourcesCount == 1) { ?>\n            </div>\n        </div>\n<? } ?>\n\n    </div>\n</div>\n"
  , __filename = "src/all/data/ejs/resource/shareDialog.ejs";
try {
  var __output = [], __append = __output.push.bind(__output);
  with (locals || {}) {
    ; __append("<div class=\"dialog-wrapper\">\n    <div class=\"dialog share-password-dialog\">\n        <div class=\"dialog-header\">\n")
    ; __line = 4
    ;  if (resourcesCount > 1) { 
    ; __append("\n            <h2><span>Share ")
    ; __line = 5
    ; __append(escapeFn( resourcesCount ))
    ; __append(" passwords </span></h2>\n")
    ; __line = 6
    ;  } else { 
    ; __append("\n            <h2>Share<span class=\"dialog-header-subtitle\"></span></h2>\n")
    ; __line = 8
    ;  } 
    ; __append("\n            <a class=\"dialog-close js-dialog-close\">\n                <i class=\"fa fa-close\"></i>\n                <span class=\"visuallyhidden\">close</span>\n            </a>\n        </div>\n        <div class=\"js-dialog-content dialog-content\">\n\n")
    ; __line = 16
    ;  if (resourcesCount == 1) { 
    ; __append("\n            <ul class=\"tabs-nav menu\">\n                <li id=\"js-share-go-to-edit\">\n                    <div class=\"row\">\n                        <div class=\"main-cell-wrapper\">\n                            <div class=\"main-cell\">\n                                <a><span>Edit</span></a>\n                            </div>\n                        </div>\n                    </div>\n                </li>\n                <li id=\"js-share-go-to-share\" class=\"\">\n                    <div class=\"row\">\n                        <div class=\"main-cell-wrapper\">\n                            <div class=\"main-cell\">\n                                <a class=\"selected\"><span>Share</span></a>\n                            </div>\n                        </div>\n                    </div>\n                </li>\n            </ul>\n\n            <div class=\"tab\">\n                <div class=\"tab-content\" style=\"display:block\">\n")
    ; __line = 40
    ;  } 
    ; __append("\n\n                    <div class=\"processing-wrapper\">\n                        <span class=\"processing-text\">Retrieving permissions</span>\n                    </div>\n\n                    <div id=\"js-share-edit-list\" class=\"form-content permission-edit\">\n                        <ul class=\"permissions scroll\"></ul>\n                    </div>\n\n                    <div id=\"js-share-feedbacks\" class=\"feedbacks message hidden\"></div>\n\n                    <div id=\"js-share-form-content-add\" class=\"form-content permission-add hidden\">\n                        <div class=\"input text autocomplete\">\n                            <label for=\"js-search-aros-input\">Share with people or groups</label>\n                            <input maxlength=\"255\" id=\"js-search-aros-input\" placeholder=\"enter one name or email\" autocomplete=\"off\" type=\"text\">\n                            <div class=\"security-token\"></div>\n                        </div>\n                        <div id=\"js-search-aro-autocomplete\" class=\"autocomplete-wrapper hidden\">\n                            <div class=\"autocomplete-content scroll\"></div>\n                        </div>\n                    </div>\n\n                    <div class=\"submit-wrapper clearfix\">\n                        <input id=\"js-share-save\" type=\"submit\" class=\"button disabled primary\" value=\"save\" disabled=\"disabled\"/>\n                        <a id=\"js-share-cancel\" class=\"cancel\">cancel</a>\n                    </div>\n                </div>\n\n")
    ; __line = 69
    ;  if (resourcesCount == 1) { 
    ; __append("\n            </div>\n        </div>\n")
    ; __line = 72
    ;  } 
    ; __append("\n\n    </div>\n</div>\n")
    ; __line = 76
  }
  return __output.join("");
} catch (e) {
  rethrow(e, __lines, __filename, __line, escapeFn);
}

}
},{}],6:[function(require,module,exports){
module.exports = function(locals, escapeFn, include, rethrow
/*``*/) {
rethrow = rethrow || function rethrow(err, str, flnm, lineno, esc){
  var lines = str.split('\n');
  var start = Math.max(lineno - 3, 0);
  var end = Math.min(lines.length, lineno + 3);
  var filename = esc(flnm); // eslint-disable-line
  // Error context
  var context = lines.slice(start, end).map(function (line, i){
    var curr = i + start + 1;
    return (curr == lineno ? ' >> ' : '    ')
      + curr
      + '| '
      + line;
  }).join('\n');

  // Alter exception message
  err.path = filename;
  err.message = (filename || 'ejs') + ':'
    + lineno + '\n'
    + context + '\n\n'
    + err.message;

  throw err;
};
escapeFn = escapeFn || function (markup) {
  return markup == undefined
    ? ''
    : String(markup)
      .replace(_MATCH_HTML, encode_char);
};
var _ENCODE_HTML_RULES = {
      "&": "&amp;"
    , "<": "&lt;"
    , ">": "&gt;"
    , '"': "&#34;"
    , "'": "&#39;"
    }
  , _MATCH_HTML = /[&<>'"]/g;
function encode_char(c) {
  return _ENCODE_HTML_RULES[c] || c;
};
;
var __line = 1
  , __lines = "<div class=\"input text autocomplete\">\n    <label for=\"js-search-aros-input\">Share with people or groups</label>\n    <input maxlength=\"255\" id=\"js-search-aros-input\" placeholder=\"enter one name or email\" autocomplete=\"off\" type=\"text\">\n    <div class=\"security-token\"></div>\n</div>\n<div id=\"js-search-aro-autocomplete\" class=\"autocomplete-wrapper hidden\">\n    <div class=\"autocomplete-content scroll\"></div>\n</div>\n"
  , __filename = "src/all/data/ejs/resource/shareFormAdd.ejs";
try {
  var __output = [], __append = __output.push.bind(__output);
  with (locals || {}) {
    ; __append("<div class=\"input text autocomplete\">\n    <label for=\"js-search-aros-input\">Share with people or groups</label>\n    <input maxlength=\"255\" id=\"js-search-aros-input\" placeholder=\"enter one name or email\" autocomplete=\"off\" type=\"text\">\n    <div class=\"security-token\"></div>\n</div>\n<div id=\"js-search-aro-autocomplete\" class=\"autocomplete-wrapper hidden\">\n    <div class=\"autocomplete-content scroll\"></div>\n</div>\n")
    ; __line = 9
  }
  return __output.join("");
} catch (e) {
  rethrow(e, __lines, __filename, __line, escapeFn);
}

}
},{}]},{},[1]);
