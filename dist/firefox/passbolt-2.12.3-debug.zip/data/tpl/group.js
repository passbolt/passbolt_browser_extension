(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
window.templates = window.templates || {};
window.templates.group = window.templates.group || {};
window.templates.group.edit = require('./group/edit.js');
window.templates.group.editAutocomplete = require('./group/editAutocomplete.js');
window.templates.group.editAutocompleteItem = require('./group/editAutocompleteItem.js');
window.templates.group.editAutocompleteItemEmpty = require('./group/editAutocompleteItemEmpty.js');

},{"./group/edit.js":2,"./group/editAutocomplete.js":3,"./group/editAutocompleteItem.js":4,"./group/editAutocompleteItemEmpty.js":5}],2:[function(require,module,exports){
module.exports = function(locals, escapeFn, include, rethrow
) {
rethrow = rethrow || function rethrow(err, str, flnm, lineno, esc){
  var lines = str.split('\n');
  var start = Math.max(lineno - 3, 0);
  var end = Math.min(lines.length, lineno + 3);
  var filename = esc(flnm); // eslint-disable-line
  // Error context
  var context = lines.slice(start, end).map(function (line, i){
    var curr = i + start + 1;
    return (curr == lineno ? ' >> ' : '    ')
      + curr
      + '| '
      + line;
  }).join('\n');

  // Alter exception message
  err.path = filename;
  err.message = (filename || 'ejs') + ':'
    + lineno + '\n'
    + context + '\n\n'
    + err.message;

  throw err;
};
escapeFn = escapeFn || function (markup) {
  return markup == undefined
    ? ''
    : String(markup)
      .replace(_MATCH_HTML, encode_char);
};
var _ENCODE_HTML_RULES = {
      "&": "&amp;"
    , "<": "&lt;"
    , ">": "&gt;"
    , '"': "&#34;"
    , "'": "&#39;"
    }
  , _MATCH_HTML = /[&<>'"]/g;
function encode_char(c) {
  return _ENCODE_HTML_RULES[c] || c;
};
;
var __line = 1
  , __lines = "<div class=\"form-content user-add permission-add\">\n    <div class=\"input text autocomplete\">\n        <label for=\"js_group_edit_form_auto_cplt\">Add people</label>\n        <input maxlength=\"255\" id=\"js_group_edit_form_auto_cplt\" placeholder=\"start typing a person name\" autocomplete=\"off\" type=\"text\">\n        <div class=\"security-token\"></div>\n    </div>\n    <div class=\"input blank\">\n        <div id=\"js_group_edit_form_feedback\" class=\"message\"></div>\n    </div>\n</div>\n"
  , __filename = "src/all/data/ejs/group/edit.ejs";
try {
  var __output = "";
  function __append(s) { if (s !== undefined && s !== null) __output += s }
  with (locals || {}) {
    ; __append("<div class=\"form-content user-add permission-add\">\n    <div class=\"input text autocomplete\">\n        <label for=\"js_group_edit_form_auto_cplt\">Add people</label>\n        <input maxlength=\"255\" id=\"js_group_edit_form_auto_cplt\" placeholder=\"start typing a person name\" autocomplete=\"off\" type=\"text\">\n        <div class=\"security-token\"></div>\n    </div>\n    <div class=\"input blank\">\n        <div id=\"js_group_edit_form_feedback\" class=\"message\"></div>\n    </div>\n</div>\n")
    ; __line = 11
  }
  return __output;
} catch (e) {
  rethrow(e, __lines, __filename, __line, escapeFn);
}

//# sourceURL=src/all/data/ejs/group/edit.ejs

}
},{}],3:[function(require,module,exports){
module.exports = function(locals, escapeFn, include, rethrow
) {
rethrow = rethrow || function rethrow(err, str, flnm, lineno, esc){
  var lines = str.split('\n');
  var start = Math.max(lineno - 3, 0);
  var end = Math.min(lines.length, lineno + 3);
  var filename = esc(flnm); // eslint-disable-line
  // Error context
  var context = lines.slice(start, end).map(function (line, i){
    var curr = i + start + 1;
    return (curr == lineno ? ' >> ' : '    ')
      + curr
      + '| '
      + line;
  }).join('\n');

  // Alter exception message
  err.path = filename;
  err.message = (filename || 'ejs') + ':'
    + lineno + '\n'
    + context + '\n\n'
    + err.message;

  throw err;
};
escapeFn = escapeFn || function (markup) {
  return markup == undefined
    ? ''
    : String(markup)
      .replace(_MATCH_HTML, encode_char);
};
var _ENCODE_HTML_RULES = {
      "&": "&amp;"
    , "<": "&lt;"
    , ">": "&gt;"
    , '"': "&#34;"
    , "'": "&#39;"
    }
  , _MATCH_HTML = /[&<>'"]/g;
function encode_char(c) {
  return _ENCODE_HTML_RULES[c] || c;
};
;
var __line = 1
  , __lines = "<div class=\"autocomplete-wrapper\">\n    <div class=\"autocomplete-content scroll\">\n        <ul></ul>\n    </div>\n</div>\n"
  , __filename = "src/all/data/ejs/group/editAutocomplete.ejs";
try {
  var __output = "";
  function __append(s) { if (s !== undefined && s !== null) __output += s }
  with (locals || {}) {
    ; __append("<div class=\"autocomplete-wrapper\">\n    <div class=\"autocomplete-content scroll\">\n        <ul></ul>\n    </div>\n</div>\n")
    ; __line = 6
  }
  return __output;
} catch (e) {
  rethrow(e, __lines, __filename, __line, escapeFn);
}

//# sourceURL=src/all/data/ejs/group/editAutocomplete.ejs

}
},{}],4:[function(require,module,exports){
module.exports = function(locals, escapeFn, include, rethrow
) {
rethrow = rethrow || function rethrow(err, str, flnm, lineno, esc){
  var lines = str.split('\n');
  var start = Math.max(lineno - 3, 0);
  var end = Math.min(lines.length, lineno + 3);
  var filename = esc(flnm); // eslint-disable-line
  // Error context
  var context = lines.slice(start, end).map(function (line, i){
    var curr = i + start + 1;
    return (curr == lineno ? ' >> ' : '    ')
      + curr
      + '| '
      + line;
  }).join('\n');

  // Alter exception message
  err.path = filename;
  err.message = (filename || 'ejs') + ':'
    + lineno + '\n'
    + context + '\n\n'
    + err.message;

  throw err;
};
escapeFn = escapeFn || function (markup) {
  return markup == undefined
    ? ''
    : String(markup)
      .replace(_MATCH_HTML, encode_char);
};
var _ENCODE_HTML_RULES = {
      "&": "&amp;"
    , "<": "&lt;"
    , ">": "&gt;"
    , '"': "&#34;"
    , "'": "&#39;"
    }
  , _MATCH_HTML = /[&<>'"]/g;
function encode_char(c) {
  return _ENCODE_HTML_RULES[c] || c;
};
;
var __line = 1
  , __lines = "<?\n    let avatarPath;\n    if (user.Profile.Avatar.url.small.startsWith('https://')) {\n        avatarPath = user.Profile.Avatar.url.small;\n    } else {\n        avatarPath = settings['user.settings.trustedDomain'] + '/' + user.Profile.Avatar.url.small;\n    }\n?>\n<li id=\"<?= user.User.id ?>\">\n    <div class=\"row\">\n        <div class=\"main-cell-wrapper\">\n            <div class=\"main-cell\">\n                <a>\n                    <div class=\"avatar\">\n                        <img src=\"<?= avatarPath ?>\"/>\n                    </div>\n                    <div class=\"user\">\n                        <span class=\"name\"><?= user.Profile.first_name ?> <?= user.Profile.last_name ?> (<?= user.Gpgkey.key_id ?>)</span>\n                        <span class=\"details\" title=\"<?= user.User.username ?>\"><?= user.User.username ?></span>\n                    </div>\n                </a>\n            </div>\n        </div>\n    </div>\n</li>\n"
  , __filename = "src/all/data/ejs/group/editAutocompleteItem.ejs";
try {
  var __output = "";
  function __append(s) { if (s !== undefined && s !== null) __output += s }
  with (locals || {}) {
    ; 
    let avatarPath;
    if (user.Profile.Avatar.url.small.startsWith('https://')) {
        avatarPath = user.Profile.Avatar.url.small;
    } else {
        avatarPath = settings['user.settings.trustedDomain'] + '/' + user.Profile.Avatar.url.small;
    }

    ; __line = 8
    ; __append("\n<li id=\"")
    ; __line = 9
    ; __append(escapeFn( user.User.id ))
    ; __append("\">\n    <div class=\"row\">\n        <div class=\"main-cell-wrapper\">\n            <div class=\"main-cell\">\n                <a>\n                    <div class=\"avatar\">\n                        <img src=\"")
    ; __line = 15
    ; __append(escapeFn( avatarPath ))
    ; __append("\"/>\n                    </div>\n                    <div class=\"user\">\n                        <span class=\"name\">")
    ; __line = 18
    ; __append(escapeFn( user.Profile.first_name ))
    ; __append(" ")
    ; __append(escapeFn( user.Profile.last_name ))
    ; __append(" (")
    ; __append(escapeFn( user.Gpgkey.key_id ))
    ; __append(")</span>\n                        <span class=\"details\" title=\"")
    ; __line = 19
    ; __append(escapeFn( user.User.username ))
    ; __append("\">")
    ; __append(escapeFn( user.User.username ))
    ; __append("</span>\n                    </div>\n                </a>\n            </div>\n        </div>\n    </div>\n</li>\n")
    ; __line = 26
  }
  return __output;
} catch (e) {
  rethrow(e, __lines, __filename, __line, escapeFn);
}

//# sourceURL=src/all/data/ejs/group/editAutocompleteItem.ejs

}
},{}],5:[function(require,module,exports){
module.exports = function(locals, escapeFn, include, rethrow
) {
rethrow = rethrow || function rethrow(err, str, flnm, lineno, esc){
  var lines = str.split('\n');
  var start = Math.max(lineno - 3, 0);
  var end = Math.min(lines.length, lineno + 3);
  var filename = esc(flnm); // eslint-disable-line
  // Error context
  var context = lines.slice(start, end).map(function (line, i){
    var curr = i + start + 1;
    return (curr == lineno ? ' >> ' : '    ')
      + curr
      + '| '
      + line;
  }).join('\n');

  // Alter exception message
  err.path = filename;
  err.message = (filename || 'ejs') + ':'
    + lineno + '\n'
    + context + '\n\n'
    + err.message;

  throw err;
};
escapeFn = escapeFn || function (markup) {
  return markup == undefined
    ? ''
    : String(markup)
      .replace(_MATCH_HTML, encode_char);
};
var _ENCODE_HTML_RULES = {
      "&": "&amp;"
    , "<": "&lt;"
    , ">": "&gt;"
    , '"': "&#34;"
    , "'": "&#39;"
    }
  , _MATCH_HTML = /[&<>'"]/g;
function encode_char(c) {
  return _ENCODE_HTML_RULES[c] || c;
};
;
var __line = 1
  , __lines = "<li>\n    <div class=\"row\">\n        <div class=\"main-cell-wrapper\">\n            <div class=\"main-cell\" style=\"font-size:16px;\">\n                No user found\n            </div>\n        </div>\n    </div>\n</li>\n"
  , __filename = "src/all/data/ejs/group/editAutocompleteItemEmpty.ejs";
try {
  var __output = "";
  function __append(s) { if (s !== undefined && s !== null) __output += s }
  with (locals || {}) {
    ; __append("<li>\n    <div class=\"row\">\n        <div class=\"main-cell-wrapper\">\n            <div class=\"main-cell\" style=\"font-size:16px;\">\n                No user found\n            </div>\n        </div>\n    </div>\n</li>\n")
    ; __line = 10
  }
  return __output;
} catch (e) {
  rethrow(e, __lines, __filename, __line, escapeFn);
}

//# sourceURL=src/all/data/ejs/group/editAutocompleteItemEmpty.ejs

}
},{}]},{},[1]);
//result must be structured-clonable data
undefined;
